import React, { useState } from 'react';
import { Star, ArrowRight, Bookmark, Check, TrendingUp, Sparkles, Tag } from 'lucide-react';

interface ProductData {
    id: string;
    vol: string;
    title: string;
    type: string;
    price: string;
    bgColor: string;
    image?: string;
    isBestseller?: boolean;
    tags?: string[];
    trending?: string;
}

interface ProductCardProps {
  product: ProductData;
  onView: () => void;
  onSave: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onView, onSave }) => {
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSave();
    setIsSaved(true);
  };

  return (
    <div onClick={onView} className="group cursor-pointer relative fade-in-up">
      {/* Book Cover visual */}
      <div className={`relative aspect-[3/4] ${product.bgColor} rounded-r-2xl rounded-l-md shadow-sm border border-brand-taupe/50 mb-6 transition-all duration-500 group-hover:shadow-book group-hover:-translate-y-2 group-hover:-translate-x-1 overflow-hidden`}>
        {/* Spine shadow */}
        <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black/5 to-transparent z-10 pointer-events-none"></div>
        
        {/* Bookmark Button */}
        <button 
            onClick={handleSave}
            className={`absolute top-4 left-4 z-30 w-8 h-8 flex items-center justify-center rounded-full backdrop-blur-md border border-brand-taupe/20 transition-all duration-300 ${isSaved ? 'bg-brand-rose text-white shadow-glow' : 'bg-white/60 text-brand-espresso hover:bg-brand-rose hover:text-white'}`}
            aria-label="Bookmark this product"
        >
            {isSaved ? <Check size={14} /> : <Bookmark size={14} />}
        </button>

        {product.image ? (
            <img 
                src={product.image} 
                alt={product.title} 
                className="absolute inset-0 w-full h-full object-cover"
            />
        ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]">
                <span className="text-[9px] uppercase tracking-[0.3em] text-brand-text/60 mb-8">{product.vol}</span>
                <h3 className="font-serif text-3xl text-brand-espresso leading-none italic mb-2">{product.title}</h3>
                <div className="w-px h-12 bg-brand-rose/50 my-6"></div>
                <span className="text-[9px] uppercase tracking-widest text-brand-text border border-brand-taupe px-3 py-1 rounded-full">{product.type}</span>
            </div>
        )}
        
        {product.trending && (
          <div className="absolute top-4 right-4 bg-brand-espresso/90 backdrop-blur text-white text-[8px] uppercase tracking-widest px-2 py-1 rounded-sm shadow-sm flex items-center gap-1 z-20">
             <Sparkles size={8} /> {product.trending}
          </div>
        )}
        
        {/* View Details Overlay */}
        <div className="absolute inset-0 bg-brand-espresso/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-6 z-20">
            <span className="bg-white text-brand-espresso px-6 py-3 rounded-full shadow-lg font-medium text-xs uppercase tracking-widest hover:bg-brand-rose hover:text-white transition-colors flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform">
                View Details <ArrowRight size={14} />
            </span>
        </div>
      </div>
      
      {/* Product Details */}
      <div className="text-center px-4">
        <h3 className="font-serif text-lg text-brand-espresso mb-1">{product.title} Guide</h3>
        <p className="text-xs text-brand-text font-light mb-2">From ${product.price}</p>
        
        {/* Tags */}
        <div className="flex flex-wrap justify-center gap-1">
            {product.tags?.slice(0, 2).map(tag => (
                <span key={tag} className="text-[8px] uppercase tracking-wider text-brand-text/60 border border-brand-taupe px-1.5 py-0.5 rounded-full">{tag}</span>
            ))}
        </div>
      </div>
    </div>
  );
};

interface LibraryProps {
  products: ProductData[];
  onViewProduct: (id: string) => void;
  onSave?: (item: any) => void;
}

const Library: React.FC<LibraryProps> = ({ products, onViewProduct, onSave }) => {
  const [filter, setFilter] = useState('All');
  const allTags = ['All', ...Array.from(new Set(products.flatMap(p => p.tags || [])))];

  const filteredProducts = filter === 'All' ? products : products.filter(p => p.tags?.includes(filter));

  return (
    <section id="library" className="pt-32 pb-24 min-h-screen max-w-7xl mx-auto px-6 bg-brand-nude">
        <div className="text-center max-w-2xl mx-auto mb-12 fade-in-up">
            <span className="text-brand-rose font-medium tracking-widest text-[10px] uppercase mb-4 block">Explore</span>
            <h2 className="font-serif text-4xl md:text-5xl text-brand-espresso tracking-tight mb-6">Discover <span className="italic text-brand-rose">Something New</span></h2>
            <p className="text-sm text-brand-text font-light">
                Curated collections for every season of your life.
            </p>
        </div>

        {/* Mood/Tag Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-16 fade-in-up">
            {allTags.map(tag => (
                <button 
                    key={tag}
                    onClick={() => setFilter(tag)}
                    className={`px-4 py-2 rounded-full text-[10px] uppercase tracking-widest transition-all ${filter === tag ? 'bg-brand-espresso text-brand-blush' : 'bg-white border border-brand-taupe text-brand-text hover:border-brand-rose'}`}
                >
                    {tag}
                </button>
            ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredProducts.map(product => (
                <ProductCard 
                    key={product.id} 
                    product={product} 
                    onView={() => onViewProduct(product.id)} 
                    onSave={() => onSave && onSave(product)} 
                />
            ))}
        </div>
    </section>
  );
};

export default Library;