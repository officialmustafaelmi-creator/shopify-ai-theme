import React from 'react';
import { BatteryMedium, Coffee, Sparkles } from 'lucide-react';

interface HeroProps {
  onNavigate: (view: any) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-notebook opacity-50 z-0 pointer-events-none"></div>
      <div className="absolute inset-0 bg-grain z-0 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-12 gap-12 items-center relative z-10">
        
        {/* Left: Text Content */}
        <div className="md:col-span-6 flex flex-col items-center md:items-start text-center md:text-left fade-in-up" style={{ animationDelay: '0.1s' }}>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/60 border border-brand-taupe mb-6 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-brand-rose animate-pulse"></span>
            <span className="text-[10px] uppercase tracking-widest font-medium text-brand-text">The digital stationery shop</span>
          </div>
          
          <h1 className="font-serif text-5xl md:text-7xl text-brand-espresso leading-[1.1] mb-6">
            Make your <br />
            <span className="italic text-brand-rose">inner life</span> pretty.
          </h1>
          
          <p className="text-brand-text text-sm md:text-base font-light leading-relaxed max-w-md mb-10">
            Digital journals, planners, and guides designed to help you romanticize your daily rituals, calm your mind, and organize your dreams.
          </p>

          <div className="flex items-center gap-4">
            <button onClick={() => onNavigate('library')} className="px-8 py-4 bg-brand-espresso text-brand-blush rounded-lg font-medium tracking-wide text-xs uppercase hover:bg-brand-rose transition-all shadow-lg shadow-brand-espresso/20">
              Browse the Library
            </button>
            <a href="#manifesto" className="px-8 py-4 bg-white/70 backdrop-blur border border-brand-taupe text-brand-espresso rounded-lg font-medium tracking-wide text-xs uppercase hover:border-brand-rose hover:text-brand-rose transition-all">
              Read the Manifesto
            </a>
          </div>
        </div>

        {/* Right: The Vibe (Collage/Desk) */}
        <div className="md:col-span-6 relative h-[500px] w-full flex items-center justify-center fade-in-up" style={{ animationDelay: '0.2s' }}>
            
            {/* The "iPad" Journal */}
            <div className="absolute z-20 w-72 md:w-80 aspect-[3/4] bg-brand-paper rounded-2xl shadow-float border-4 border-white transform -rotate-3 hover:rotate-0 transition-transform duration-700 overflow-hidden group cursor-pointer">
                <div className="h-full w-full p-6 flex flex-col relative bg-[url('https://www.transparenttextures.com/patterns/paper.png')]">
                    {/* iPad content simulation */}
                    <div className="flex justify-between items-center mb-6 opacity-50 text-brand-text">
                        <span className="text-[8px] uppercase tracking-widest">Oct 24</span>
                        <BatteryMedium size={14} />
                    </div>
                    <h3 className="font-serif text-2xl text-brand-espresso mb-2">Morning Pages</h3>
                    <div className="w-12 h-0.5 bg-brand-rose mb-4"></div>
                    <div className="space-y-3 font-serif text-sm text-brand-text/70 italic leading-relaxed">
                        <p>"I am becoming the woman of my dreams, slowly and softly..."</p>
                        <p className="opacity-60">Coffee is warm. The light is perfect.</p>
                    </div>
                    
                    {/* Stickers */}
                    <div className="absolute bottom-6 right-6 transform rotate-12 group-hover:scale-110 transition-transform">
                         <div className="bg-brand-rose/20 text-brand-rose px-3 py-1 rounded-full text-[10px] uppercase font-bold border border-brand-rose/30">Vibes</div>
                    </div>
                </div>
            </div>

            {/* Background "Book" */}
            <div className="absolute z-10 w-72 md:w-80 aspect-[3/4] bg-[#E8DED8] rounded-r-xl rounded-l-sm shadow-book transform rotate-6 translate-x-12 translate-y-4 border-l-4 border-[#D6CCC6]">
                <div className="absolute right-4 bottom-4 font-serif text-6xl text-white/40 italic">Vol. 2</div>
            </div>

            {/* Floating Elements */}
            <div className="absolute top-10 right-10 bg-white p-3 shadow-lg rounded-lg transform rotate-12 animate-float-slow z-30">
                <Coffee className="text-brand-rose" size={24} />
            </div>
            
            <div className="absolute bottom-20 left-0 md:-left-4 bg-white px-4 py-3 shadow-lg rounded-lg transform -rotate-6 animate-float-delayed z-30 border border-brand-taupe/50">
                <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                    <span className="text-[10px] uppercase tracking-widest font-medium text-brand-espresso">Reading Now</span>
                </div>
                <p className="font-serif text-sm mt-1 italic">"The Art of Being"</p>
            </div>

            <div className="absolute top-0 left-20 opacity-40">
                <Sparkles className="text-brand-espresso" size={32} />
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;