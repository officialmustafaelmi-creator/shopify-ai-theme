import React from 'react';
import { Feather, Instagram, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-nude pt-20 pb-10 border-t border-brand-taupe">
        <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-16">
                <div className="max-w-xs">
                    <a href="#" className="font-serif text-3xl tracking-tight text-brand-espresso mb-6 flex items-center gap-2">
                        <Feather className="text-brand-rose" size={20} />
                        MPT.
                    </a>
                    <p className="text-xs text-brand-text leading-relaxed mb-6">
                        A digital boutique for the dreamer, the writer, and the woman becoming her own muse.
                    </p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-12 w-full md:w-auto">
                    <div>
                        <h4 className="font-serif text-brand-espresso text-lg mb-4 italic">Library</h4>
                        <ul className="space-y-3 text-xs uppercase tracking-wide text-brand-text">
                            <li><a href="#" className="hover:text-brand-rose transition-colors">Journals</a></li>
                            <li><a href="#" className="hover:text-brand-rose transition-colors">Planners</a></li>
                            <li><a href="#" className="hover:text-brand-rose transition-colors">Stickers</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-serif text-brand-espresso text-lg mb-4 italic">Info</h4>
                        <ul className="space-y-3 text-xs uppercase tracking-wide text-brand-text">
                            <li><a href="#" className="hover:text-brand-rose transition-colors">FAQ</a></li>
                            <li><a href="#" className="hover:text-brand-rose transition-colors">Contact</a></li>
                            <li><a href="#" className="hover:text-brand-rose transition-colors">Returns</a></li>
                        </ul>
                    </div>
                    <div className="col-span-2 md:col-span-1">
                        <h4 className="font-serif text-brand-espresso text-lg mb-4 italic">Letters</h4>
                        <div className="flex border-b border-brand-taupe pb-2">
                            <input type="email" placeholder="Your email address" className="bg-transparent w-full text-xs outline-none text-brand-espresso placeholder:text-brand-taupe/80" />
                            <button className="text-xs uppercase tracking-widest text-brand-text hover:text-brand-rose transition-colors">Send</button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-brand-taupe/30 gap-4">
                <p className="text-[10px] text-brand-text/60 uppercase tracking-widest">© 2024 My Pretty Thoughts.</p>
                <div className="flex gap-4">
                    <a href="#" className="text-brand-text hover:text-brand-rose"><Instagram size={16} /></a>
                    <a href="#" className="text-brand-text hover:text-brand-rose"><Twitter size={16} /></a>
                    {/* Pinterest Icon Placeholder since Lucide doesn't have it standard */}
                    <a href="#" className="text-brand-text hover:text-brand-rose">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 12a4 4 0 1 0 8 0"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m4.9 4.9 1.4 1.4"/><path d="m17.7 17.7 1.4 1.4"/><path d="m4.9 19.1 1.4-1.4"/><path d="m17.7 6.3 1.4-1.4"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </footer>
  );
};

export default Footer;