import React, { useRef, useEffect } from 'react';
import { Play, Pause, X, SkipForward, SkipBack, Volume2 } from 'lucide-react';

export interface Track {
    id: string;
    title: string;
    duration: string;
    coverColor: string;
}

interface AudioPlayerProps {
    track: Track;
    isPlaying: boolean;
    onTogglePlay: () => void;
    onClose: () => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ track, isPlaying, onTogglePlay, onClose }) => {
  // Mock progress simulation
  const [progress, setProgress] = React.useState(0);
  
  useEffect(() => {
      let interval: number;
      if (isPlaying) {
          interval = window.setInterval(() => {
              setProgress(p => (p >= 100 ? 0 : p + 0.5));
          }, 1000);
      }
      return () => clearInterval(interval);
  }, [isPlaying]);

  return (
    <div className="fixed bottom-0 left-0 w-full z-50 animate-fade-in">
        <div className="mx-auto max-w-2xl md:mb-6 md:rounded-2xl overflow-hidden bg-white/90 backdrop-blur-xl border border-brand-taupe shadow-2xl shadow-brand-espresso/20">
            {/* Progress Bar */}
            <div className="h-1 bg-brand-taupe/30 w-full">
                <div className="h-full bg-brand-rose transition-all duration-1000" style={{ width: `${progress}%` }}></div>
            </div>
            
            <div className="p-4 flex items-center gap-4">
                {/* Album Art */}
                <div className={`w-12 h-12 rounded-lg ${track.coverColor} flex-shrink-0 flex items-center justify-center shadow-inner`}>
                    <div className="w-4 h-4 rounded-full bg-white/30 animate-pulse"></div>
                </div>

                {/* Info */}
                <div className="flex-grow min-w-0">
                    <h4 className="text-sm font-serif text-brand-espresso truncate">{track.title}</h4>
                    <p className="text-[10px] text-brand-text uppercase tracking-widest">Audio Comfort • {track.duration}</p>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-3">
                    <button className="hidden sm:block text-brand-text hover:text-brand-espresso">
                        <SkipBack size={16} />
                    </button>
                    <button 
                        onClick={onTogglePlay}
                        className="w-10 h-10 rounded-full bg-brand-espresso text-brand-blush flex items-center justify-center hover:bg-brand-rose transition-colors shadow-lg"
                    >
                        {isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
                    </button>
                    <button className="hidden sm:block text-brand-text hover:text-brand-espresso">
                        <SkipForward size={16} />
                    </button>
                </div>

                {/* Close */}
                <button onClick={onClose} className="p-2 text-brand-text hover:text-brand-espresso border-l border-brand-taupe pl-4 ml-2">
                    <X size={16} />
                </button>
            </div>
        </div>
    </div>
  );
};

export default AudioPlayer;