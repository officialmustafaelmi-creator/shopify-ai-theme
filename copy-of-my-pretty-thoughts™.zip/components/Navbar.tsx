import React, { useState } from 'react';
import { Menu, ArrowRight, X, User, Headphones, Book, Bell } from 'lucide-react';

interface NavbarProps {
  onNavigate: (view: 'home' | 'club' | 'login' | 'comfort' | 'journal' | 'library' | 'profile') => void;
  user?: { name: string, displayName?: string } | null;
  onLogout?: () => void;
  notifications?: { id: string, text: string, read: boolean }[];
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, user, onLogout, notifications = [] }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  const handleLinkClick = (e: React.MouseEvent, targetId: string) => {
    e.preventDefault();
    closeMobileMenu();
    onNavigate('home');
    setTimeout(() => {
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <nav className="fixed top-0 w-full z-50 bg-brand-nude/80 backdrop-blur-md border-b border-brand-taupe transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-brand-espresso p-2" 
          aria-label="Open menu"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Logo */}
        <button onClick={() => onNavigate('home')} className="text-brand-espresso hover:text-brand-rose transition-colors flex items-center gap-2 text-2xl tracking-tight font-serif">
          My Pretty Thoughts™
        </button>

        {/* Mobile Menu Dropdown */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-20 left-0 w-full bg-brand-nude/95 backdrop-blur-md border-b border-brand-taupe shadow-xl">
            <div className="px-6 py-6 flex flex-col gap-4 text-sm font-medium font-sans">
              {user ? (
                 <div className="pb-4 border-b border-brand-taupe mb-2" onClick={() => { onNavigate('profile'); closeMobileMenu(); }}>
                    <p className="text-xs uppercase tracking-widest text-brand-text mb-1">Signed in as</p>
                    <p className="font-serif text-lg text-brand-espresso">{user.displayName || user.name}</p>
                 </div>
              ) : null}
              
              <button onClick={() => { onNavigate('library'); closeMobileMenu(); }} className="text-left hover:text-brand-rose w-full">Discover</button>
              <button onClick={() => { onNavigate('comfort'); closeMobileMenu(); }} className="text-left hover:text-brand-rose w-full flex items-center gap-2"><Headphones size={14}/> Audio</button>
              <button onClick={() => { onNavigate('journal'); closeMobileMenu(); }} className="text-left hover:text-brand-rose w-full flex items-center gap-2"><Book size={14}/> Journal</button>
              <button onClick={() => { onNavigate('club'); closeMobileMenu(); }} className="text-left hover:text-brand-rose w-full">Community</button>
              
              {user ? (
                  <button onClick={() => { if(onLogout) onLogout(); closeMobileMenu(); }} className="text-left text-brand-text hover:text-brand-rose w-full text-xs uppercase tracking-widest">Sign Out</button>
              ) : (
                  <button onClick={() => { onNavigate('login'); closeMobileMenu(); }} className="text-left text-brand-espresso font-bold hover:text-brand-rose w-full">Login</button>
              )}
            </div>
          </div>
        )}

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8 text-xs font-medium tracking-[0.15em] uppercase text-brand-text font-sans">
          <button onClick={() => onNavigate('library')} className="hover:text-brand-rose transition-colors">Discover</button>
          <button onClick={() => onNavigate('comfort')} className="hover:text-brand-rose transition-colors">Audio</button>
          <button onClick={() => onNavigate('journal')} className="hover:text-brand-rose transition-colors">Journal</button>
          <button onClick={() => onNavigate('club')} className="hover:text-brand-rose transition-colors">Community</button>
        </div>

        {/* Icons / Actions */}
        <div className="hidden md:flex items-center gap-6 font-sans">
          
          {user && (
              <div className="relative">
                  <button onClick={() => setShowNotifications(!showNotifications)} className="text-brand-text hover:text-brand-espresso transition-colors">
                      <Bell size={18} />
                      {unreadCount > 0 && <span className="absolute -top-1 -right-1 w-2 h-2 bg-brand-rose rounded-full"></span>}
                  </button>
                  
                  {showNotifications && (
                      <div className="absolute top-10 right-0 w-64 bg-white rounded-xl shadow-xl border border-brand-taupe p-4 animate-fade-in z-50">
                          <h4 className="font-serif text-sm text-brand-espresso mb-3 border-b border-brand-taupe/30 pb-2">Notifications</h4>
                          {notifications.length > 0 ? (
                              <ul className="space-y-3">
                                  {notifications.map(n => (
                                      <li key={n.id} className="text-xs text-brand-text leading-relaxed">
                                          {!n.read && <span className="w-1.5 h-1.5 bg-brand-rose rounded-full inline-block mr-2"></span>}
                                          {n.text}
                                      </li>
                                  ))}
                              </ul>
                          ) : (
                              <p className="text-xs text-brand-text/50 italic">No new notifications.</p>
                          )}
                      </div>
                  )}
              </div>
          )}

          {user ? (
             <div className="flex items-center gap-4">
                 <button onClick={() => onNavigate('profile')} className="text-brand-espresso font-serif italic text-sm hover:text-brand-rose transition-colors">
                     {user.displayName || user.name}
                 </button>
                 <button onClick={onLogout} className="text-[10px] uppercase tracking-widest text-brand-text hover:text-brand-rose transition-colors">
                    Sign Out
                 </button>
             </div>
          ) : (
             <button onClick={() => onNavigate('login')} className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-brand-espresso hover:text-brand-rose transition-colors font-medium">
                <User size={14} />
                <span>Login</span>
             </button>
          )}

          <a href="#manifesto" onClick={(e) => handleLinkClick(e, 'manifesto')} className="group flex items-center gap-2 text-[10px] uppercase tracking-widest text-brand-espresso font-medium pl-6 border-l border-brand-taupe">
            <span className="border-b border-brand-espresso group-hover:border-brand-rose group-hover:text-brand-rose transition-all pb-0.5">Manifesto</span>
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform text-brand-rose" />
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;