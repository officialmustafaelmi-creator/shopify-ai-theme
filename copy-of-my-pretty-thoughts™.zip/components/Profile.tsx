import React, { useState } from 'react';
import { User, Edit2, Check, BookOpen, Flame, Award, Settings, Bookmark, ShoppingBag, MessageSquare, Quote, X, RefreshCw } from 'lucide-react';
import { UserProfile, SavedItem } from '../App';

interface ProfileProps {
    user: UserProfile;
    onUpdateProfile: (data: Partial<UserProfile>) => void;
    readingProgress: Record<string, number>;
    products: any[];
    purchasedItems: SavedItem[];
    savedItems: SavedItem[];
    userReviews: any[];
    onRemove: (id: string) => void;
    onNavigate: (view: any) => void;
    onRead: (id: string) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onUpdateProfile, readingProgress, products, purchasedItems, savedItems, userReviews, onRemove, onNavigate, onRead }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user.displayName);
  const [editBio, setEditBio] = useState(user.bio);
  const [activeTab, setActiveTab] = useState<'library' | 'saved' | 'reviews'>('library');

  const handleSave = () => {
      onUpdateProfile({ displayName: editName, bio: editBio });
      setIsEditing(false);
  };

  const inProgressIds = Object.keys(readingProgress).filter(id => readingProgress[id] < 100 && readingProgress[id] > 0);
  const inProgressBooks = products.filter(p => inProgressIds.includes(p.id));

  const getProductTitle = (volId: string) => {
      const p = products.find(prod => prod.id === volId);
      return p ? p.title : volId;
  };

  return (
    <section className="min-h-screen pt-32 pb-24 bg-brand-nude">
        <div className="max-w-7xl mx-auto px-6">
            <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-brand-taupe shadow-sm mb-10 relative">
                <button onClick={() => alert("Settings would go here")} className="absolute top-8 right-8 text-brand-text/50 hover:text-brand-espresso">
                    <Settings size={18} />
                </button>
                
                <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
                    <div className="w-24 h-24 rounded-full bg-brand-espresso text-brand-blush flex items-center justify-center text-3xl font-serif border-4 border-brand-nude shadow-lg">
                        {user.displayName.charAt(0).toUpperCase()}
                    </div>
                    
                    <div className="flex-grow text-center md:text-left">
                        {isEditing ? (
                            <div className="space-y-3 max-w-sm">
                                <input 
                                    value={editName} 
                                    onChange={(e) => setEditName(e.target.value)} 
                                    className="w-full text-2xl font-serif border-b border-brand-taupe bg-transparent focus:outline-none focus:border-brand-rose"
                                    placeholder="Display Name"
                                    disabled={user.isShopifySynced}
                                />
                                <textarea 
                                    value={editBio} 
                                    onChange={(e) => setEditBio(e.target.value)} 
                                    className="w-full text-sm font-light text-brand-text border border-brand-taupe rounded p-2 focus:outline-none focus:border-brand-rose resize-none"
                                    rows={2}
                                    placeholder="Your bio..."
                                />
                                <button onClick={handleSave} className="px-4 py-1.5 bg-brand-rose text-white rounded-full text-[10px] uppercase tracking-widest flex items-center gap-2 mx-auto md:mx-0">
                                    <Check size={12} /> Save
                                </button>
                            </div>
                        ) : (
                            <>
                                <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                                    <h2 className="font-serif text-3xl text-brand-espresso">{user.displayName}</h2>
                                    {!user.isShopifySynced && (
                                        <button onClick={() => setIsEditing(true)} className="text-brand-text/40 hover:text-brand-rose transition-colors">
                                            <Edit2 size={14} />
                                        </button>
                                    )}
                                </div>
                                <p className="text-brand-text font-light mb-4">{user.bio}</p>
                                <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                                    <span className="px-3 py-1 rounded-full bg-brand-paper border border-brand-taupe text-[10px] uppercase tracking-widest text-brand-text">
                                        Joined {new Date(user.joined).toLocaleDateString()}
                                    </span>
                                    <span className="px-3 py-1 rounded-full bg-brand-rose/10 text-brand-rose text-[10px] uppercase tracking-widest font-medium">
                                        {user.tier === 'paid' ? 'Soft Member' : 'Free Spirit'}
                                    </span>
                                    {user.isShopifySynced && (
                                        <span className="px-3 py-1 rounded-full bg-green-50 border border-green-100 text-green-600 text-[10px] uppercase tracking-widest font-medium flex items-center gap-1">
                                            <RefreshCw size={10} className="animate-spin-slow" /> Synced with Shopify
                                        </span>
                                    )}
                                </div>
                            </>
                        )}
                    </div>

                    <div className="flex gap-6 mt-6 md:mt-0">
                        <div className="text-center">
                            <div className="w-12 h-12 rounded-2xl bg-orange-50 border border-orange-100 flex items-center justify-center text-orange-400 mb-2 mx-auto">
                                <Flame size={20} />
                            </div>
                            <p className="font-serif text-xl text-brand-espresso">{user.streak}</p>
                            <p className="text-[9px] text-brand-text uppercase tracking-widest">Day Streak</p>
                        </div>
                        <div className="text-center">
                            <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-400 mb-2 mx-auto">
                                <BookOpen size={20} />
                            </div>
                            <p className="font-serif text-xl text-brand-espresso">{Object.keys(readingProgress).length}</p>
                            <p className="text-[9px] text-brand-text uppercase tracking-widest">Reads</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="flex justify-center gap-2 mb-10 border-b border-brand-taupe/30 pb-1">
                <button onClick={() => setActiveTab('library')} className={`flex items-center gap-2 px-6 py-3 rounded-t-lg text-[10px] uppercase tracking-widest transition-all ${activeTab === 'library' ? 'bg-brand-espresso text-brand-blush' : 'text-brand-text hover:text-brand-espresso'}`}><BookOpen size={14} /> My Library</button>
                <button onClick={() => setActiveTab('saved')} className={`flex items-center gap-2 px-6 py-3 rounded-t-lg text-[10px] uppercase tracking-widest transition-all ${activeTab === 'saved' ? 'bg-brand-espresso text-brand-blush' : 'text-brand-text hover:text-brand-espresso'}`}><Bookmark size={14} /> Saved Items</button>
                <button onClick={() => setActiveTab('reviews')} className={`flex items-center gap-2 px-6 py-3 rounded-t-lg text-[10px] uppercase tracking-widest transition-all ${activeTab === 'reviews' ? 'bg-brand-espresso text-brand-blush' : 'text-brand-text hover:text-brand-espresso'}`}><MessageSquare size={14} /> Reviews</button>
            </div>

            {activeTab === 'library' && (
                <div className="max-w-4xl mx-auto animate-fade-in">
                    <div className="mb-12">
                        <h3 className="font-serif text-xl text-brand-espresso mb-6 flex items-center gap-2"><BookOpen size={18} className="text-brand-rose" /> Continue Reading</h3>
                        {inProgressBooks.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {inProgressBooks.map(book => (
                                    <div key={book.id} onClick={() => onRead(book.id)} className="bg-white p-6 rounded-2xl border border-brand-taupe shadow-sm cursor-pointer hover:border-brand-rose transition-colors flex gap-6 group">
                                        <div className={`w-16 h-20 rounded border border-brand-taupe/50 shadow-inner flex-shrink-0 overflow-hidden relative ${book.bgColor}`}>
                                            {book.image && <img src={book.image} alt={book.title} className="absolute inset-0 w-full h-full object-cover" />}
                                        </div>
                                        <div className="flex-grow">
                                            <h4 className="font-serif text-lg text-brand-espresso mb-1 group-hover:text-brand-rose transition-colors">{book.title}</h4>
                                            <div className="w-full bg-brand-nude rounded-full h-1.5 mb-2 overflow-hidden">
                                                <div className="bg-brand-rose h-full" style={{ width: `${readingProgress[book.id]}%` }}></div>
                                            </div>
                                            <p className="text-[10px] text-brand-text uppercase tracking-widest">{readingProgress[book.id]}% Complete</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="bg-white/50 border border-brand-taupe border-dashed rounded-2xl p-8 text-center">
                                <p className="text-sm text-brand-text font-light mb-4">You have no books in progress.</p>
                                <button onClick={() => onNavigate('library')} className="text-xs uppercase tracking-widest text-brand-rose hover:text-brand-espresso transition-colors">Explore Library</button>
                            </div>
                        )}
                    </div>

                    <div>
                        <h3 className="font-serif text-xl text-brand-espresso mb-6 flex items-center gap-2"><Award size={18} className="text-brand-rose" /> My Collection</h3>
                        {purchasedItems.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {purchasedItems.map(item => (
                                    <div key={item.id} className="bg-white p-6 rounded-2xl border border-brand-taupe shadow-book flex items-center gap-6 group cursor-pointer" onClick={() => {
                                         const prod = products.find(p => p.title === item.title?.split('(')[0].trim());
                                         if(prod) onRead(prod.id);
                                    }}>
                                        <div className={`w-16 h-20 rounded-r-md rounded-l-sm shadow-inner border border-brand-taupe/30 flex-shrink-0 relative overflow-hidden ${item.content}`}>
                                            {item.image && <img src={item.image} alt={item.title} className="absolute inset-0 w-full h-full object-cover" />}
                                        </div>
                                        <div>
                                            <h3 className="font-serif text-lg text-brand-espresso group-hover:text-brand-rose transition-colors">{item.title}</h3>
                                            <div className="flex items-center gap-2 mt-2">
                                                <span className="text-[9px] bg-green-100 text-green-800 px-2 py-0.5 rounded-full uppercase tracking-widest">Owned</span>
                                            </div>
                                            <span className="mt-2 text-[10px] border-b border-brand-text/30 uppercase tracking-widest block w-fit">Open</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-brand-text font-light italic text-center py-8 bg-brand-taupe/10 rounded-xl">Your collection is empty.</p>
                        )}
                    </div>
                </div>
            )}

            {activeTab === 'saved' && (
                <div className="max-w-7xl mx-auto animate-fade-in">
                    {savedItems.length === 0 ? (
                        <div className="text-center py-20 bg-white/50 rounded-3xl border border-brand-taupe border-dashed">
                            <p className="text-brand-text font-light mb-6">Your saved items collection is empty.</p>
                            <button onClick={() => onNavigate('library')} className="px-6 py-3 bg-brand-espresso text-brand-blush rounded-lg font-medium text-xs uppercase hover:bg-brand-rose transition-all">Go Explore</button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            {savedItems.map((item, idx) => (
                                <div key={item.id} className="relative group animate-float-slow" style={{ animationDelay: `${idx * 0.2}s` }}>
                                    <button onClick={() => onRemove(item.id)} className="absolute -top-2 -right-2 z-20 w-8 h-8 flex items-center justify-center bg-white rounded-full shadow-md text-brand-espresso hover:text-brand-rose hover:scale-110 transition-all border border-brand-taupe cursor-pointer"><X size={14} /></button>
                                    {item.type === 'affirmation' ? (
                                        <div className="bg-brand-paper p-8 rounded-xl shadow-book border border-brand-taupe h-full min-h-[300px] flex flex-col justify-center text-center relative overflow-hidden group-hover:-translate-y-1 transition-transform duration-300">
                                            <Quote className="absolute top-6 left-6 text-brand-rose/20" size={40} />
                                            <p className="font-serif text-xl text-brand-espresso italic relative z-10 leading-relaxed">"{item.content}"</p>
                                            <div className="mt-6 w-12 h-px bg-brand-rose/50 mx-auto"></div>
                                        </div>
                                    ) : item.type === 'mood' ? (
                                        <div className="aspect-[4/5] bg-brand-nude rounded-lg overflow-hidden shadow-book border border-brand-taupe relative group-hover:-translate-y-1 transition-transform duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                                                <rect width="100%" height="100%" fill={item.content} /><text x="50%" y="50%" fontFamily="serif" fontSize="20" fill={item.textColor || "#4A3B39"} textAnchor="middle" dominantBaseline="middle" fontStyle="italic">{item.title}</text>
                                            </svg>
                                        </div>
                                    ) : (
                                        <div className="h-full bg-white rounded-xl shadow-sm border border-brand-taupe/50 p-4 group-hover:-translate-y-1 transition-transform duration-300">
                                            <div className={`relative aspect-[3/4] ${item.content} rounded-r-lg rounded-l-sm shadow-inner mb-4 overflow-hidden`}>
                                                {item.image ? <img src={item.image} alt={item.title} className="absolute inset-0 w-full h-full object-cover" /> : (
                                                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]">
                                                        {item.vol && <span className="text-[8px] uppercase tracking-[0.3em] text-brand-text/60 mb-4">{item.vol}</span>}<h3 className="font-serif text-xl text-brand-espresso leading-none italic mb-2">{item.title}</h3>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="text-center"><h4 className="font-serif text-base text-brand-espresso">{item.title}</h4><span className="text-[10px] uppercase tracking-widest text-brand-text mt-1 block">Saved Item</span></div>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'reviews' && (
                <div className="max-w-3xl mx-auto animate-fade-in">
                     {userReviews.length === 0 ? (
                        <div className="text-center py-20 bg-white/50 rounded-3xl border border-brand-taupe border-dashed">
                            <p className="text-brand-text font-light mb-6">You haven't posted any reviews yet.</p>
                            <button onClick={() => onNavigate('club')} className="px-6 py-3 bg-brand-espresso text-brand-blush rounded-lg font-medium text-xs uppercase hover:bg-brand-rose transition-all">Go to Book Club</button>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {userReviews.map((review) => (
                                <div key={review.id} className="bg-white p-6 rounded-2xl border border-brand-taupe shadow-sm">
                                    <div className="flex items-center justify-between mb-3">
                                        <span className="text-xs font-bold text-brand-espresso">{getProductTitle(review.productTitle)}</span>
                                        <span className="text-[9px] text-brand-text/60 uppercase tracking-widest">{review.time}</span>
                                    </div>
                                    <p className="text-sm text-brand-text font-light leading-relaxed">"{review.text}"</p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}
        </div>
    </section>
  );
};

export default Profile;
