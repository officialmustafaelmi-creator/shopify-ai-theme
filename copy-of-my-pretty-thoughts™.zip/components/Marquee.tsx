import React from 'react';
import { Star } from 'lucide-react';

const Marquee: React.FC = () => {
  const items = [
    "Romanticize Your Life",
    "Digital Stationery",
    "Main Character Energy",
    "Read. Write. Heal.",
    "Romanticize Your Life",
    "Digital Stationery"
  ];

  // Duplicate list to ensure smooth infinite scroll
  const repeatedItems = [...items, ...items, ...items, ...items];

  return (
    <div className="border-y border-brand-taupe bg-white py-3 overflow-hidden">
      <div className="flex gap-12 whitespace-nowrap animate-marquee items-center">
        {repeatedItems.map((text, i) => (
          <span key={i} className="flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-brand-text font-medium">
             <Star className="text-brand-rose" size={10} />
             {text}
          </span>
        ))}
      </div>
    </div>
  );
};

export default Marquee;