import React, { useState } from 'react';
import { ArrowRight, Feather, Mail, Lock, User, Eye, EyeOff, ArrowLeft } from 'lucide-react';

interface LoginProps {
  onLogin: (username: string) => void;
}

type AuthView = 'login' | 'register' | 'recovery';

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [view, setView] = useState<AuthView>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  
  // Recovery specific state
  const [recoveryStep, setRecoveryStep] = useState(1); // 1: Verify, 2: Reset

  // Form State
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError(''); 
    setSuccessMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const { username, email, password } = formData;
    const db = JSON.parse(localStorage.getItem('mpt_users') || '{}');

    if (view === 'register') {
        // REGISTER LOGIC
        if (!username || !email || !password) {
            setError('Please fill in all fields.');
            return;
        }

        if (db[username]) {
            setError('Username already taken.');
            return;
        }

        const newUser = {
            username,
            email,
            password,
            savedItems: [],
            purchasedItems: [],
            joined: new Date().toISOString()
        };

        db[username] = newUser;
        localStorage.setItem('mpt_users', JSON.stringify(db));
        onLogin(username);

    } else if (view === 'login') {
        // LOGIN LOGIC
        if (!username || !password) {
            setError('Please enter username and password.');
            return;
        }

        const user = db[username];

        if (!user || user.password !== password) {
            setError('Invalid username or password.');
            return;
        }

        onLogin(username);
    } else if (view === 'recovery') {
        // RECOVERY LOGIC
        const user = db[username];
        
        if (recoveryStep === 1) {
            if (!username || !email) { setError('Please fill in all fields.'); return; }
            
            if (user && user.email === email) {
                setRecoveryStep(2);
                setError('');
                setSuccessMsg('Identity verified. Set your new password.');
            } else {
                setError('Username and email do not match our records.');
            }
        } else {
            // Step 2: Set New Password
            if (!password) { setError('Please enter a new password.'); return; }
            if (password.length < 4) { setError('Password must be at least 4 characters.'); return; }
            
            user.password = password;
            db[username] = user;
            localStorage.setItem('mpt_users', JSON.stringify(db));
            
            alert('Password reset successful! Please login.');
            setView('login');
            setRecoveryStep(1);
            setFormData({ username: '', email: '', password: '' });
        }
    }
  };

  const getTitle = () => {
      if (view === 'register') return 'Create Account';
      if (view === 'recovery') return 'Reset Password';
      return 'Welcome Back';
  };

  const getButtonText = () => {
      if (view === 'register') return 'Join the Club';
      if (view === 'recovery') return recoveryStep === 1 ? 'Verify Identity' : 'Update Password';
      return 'Enter Library';
  };

  return (
    <section className="min-h-screen bg-brand-nude flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/paper.png')] opacity-50 pointer-events-none"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-rose/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-brand-espresso/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="bg-white/80 backdrop-blur-md p-8 md:p-12 rounded-3xl border border-brand-taupe shadow-float max-w-md w-full relative z-10 fade-in-up">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-brand-espresso text-brand-blush rounded-full flex items-center justify-center mx-auto mb-4 shadow-md">
            <Feather size={20} />
          </div>
          <span className="text-[10px] uppercase tracking-widest text-brand-rose font-medium mb-2 block">
            {view === 'register' ? 'Join the Club' : 'Member Access'}
          </span>
          <h2 className="font-serif text-3xl text-brand-espresso">
            {getTitle()}
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Username (Always visible except recovery step 2 optionally, but good to keep context) */}
          <div className={`space-y-1 ${view === 'recovery' && recoveryStep === 2 ? 'opacity-50 pointer-events-none' : ''}`}>
            <label className="text-[10px] uppercase tracking-widest text-brand-text/70 ml-1">Username</label>
            <div className="relative">
                <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-text/40" />
                <input 
                type="text" 
                name="username"
                autoComplete="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="prettygirl123"
                className="w-full pl-11 pr-5 py-3.5 rounded-xl bg-brand-nude border border-brand-taupe focus:border-brand-rose focus:ring-1 focus:ring-brand-rose/20 outline-none transition-all text-sm text-brand-espresso placeholder:text-brand-text/30"
                readOnly={view === 'recovery' && recoveryStep === 2}
                />
            </div>
          </div>

          {/* Email (Register OR Recovery Step 1) */}
          {(view === 'register' || (view === 'recovery' && recoveryStep === 1)) && (
            <div className="space-y-1 animate-fade-in">
                <label className="text-[10px] uppercase tracking-widest text-brand-text/70 ml-1">Email</label>
                <div className="relative">
                    <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-text/40" />
                    <input 
                    type="email" 
                    name="email"
                    autoComplete="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="you@example.com"
                    className="w-full pl-11 pr-5 py-3.5 rounded-xl bg-brand-nude border border-brand-taupe focus:border-brand-rose focus:ring-1 focus:ring-brand-rose/20 outline-none transition-all text-sm text-brand-espresso placeholder:text-brand-text/30"
                    />
                </div>
            </div>
          )}

          {/* Password (Register OR Login OR Recovery Step 2) */}
          {(view !== 'recovery' || recoveryStep === 2) && (
            <div className="space-y-1 animate-fade-in">
                <label className="text-[10px] uppercase tracking-widest text-brand-text/70 ml-1">
                    {view === 'recovery' ? 'New Password' : 'Password'}
                </label>
                <div className="relative">
                    <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-text/40" />
                    <input 
                    type={showPassword ? "text" : "password"} 
                    name="password"
                    autoComplete={view === 'register' || view === 'recovery' ? "new-password" : "current-password"}
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="••••••••"
                    className="w-full pl-11 pr-12 py-3.5 rounded-xl bg-brand-nude border border-brand-taupe focus:border-brand-rose focus:ring-1 focus:ring-brand-rose/20 outline-none transition-all text-sm text-brand-espresso placeholder:text-brand-text/30"
                    />
                    <button 
                        type="button" 
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-text/40 hover:text-brand-rose transition-colors"
                    >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                </div>
            </div>
          )}
          
          {view === 'login' && (
              <div className="flex justify-end">
                  <button 
                    type="button" 
                    onClick={() => { setView('recovery'); setError(''); setFormData({ ...formData, password: '' }); }}
                    className="text-[10px] text-brand-text hover:text-brand-espresso underline decoration-brand-taupe hover:decoration-brand-espresso transition-all"
                  >
                      Forgot Password?
                  </button>
              </div>
          )}

          {error && (
              <p className="text-xs text-red-500 text-center bg-red-50 py-2 rounded-lg border border-red-100 animate-fade-in">{error}</p>
          )}
          
          {successMsg && (
              <p className="text-xs text-green-600 text-center bg-green-50 py-2 rounded-lg border border-green-100 animate-fade-in">{successMsg}</p>
          )}

          <button 
            type="submit" 
            className="w-full bg-brand-espresso text-brand-blush py-4 rounded-xl font-medium uppercase text-xs tracking-widest hover:bg-brand-rose transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-espresso/10 mt-6"
          >
            {getButtonText()}
            <ArrowRight size={14} />
          </button>
        </form>

        <div className="mt-8 text-center pt-6 border-t border-brand-taupe/30">
            {view === 'recovery' ? (
                 <button 
                    onClick={() => { setView('login'); setError(''); setRecoveryStep(1); }}
                    className="flex items-center justify-center gap-2 mx-auto text-xs uppercase tracking-widest text-brand-text hover:text-brand-espresso transition-colors"
                >
                    <ArrowLeft size={12} /> Back to Login
                </button>
            ) : (
                <>
                    <p className="text-xs text-brand-text font-light mb-2">
                        {view === 'register' ? "Already have an account?" : "Don't have an account?"}
                    </p>
                    <button 
                        onClick={() => { setView(view === 'login' ? 'register' : 'login'); setError(''); }}
                        className="text-xs uppercase tracking-widest text-brand-espresso font-bold hover:text-brand-rose transition-colors border-b border-brand-espresso/20 pb-0.5 hover:border-brand-rose"
                    >
                        {view === 'register' ? "Sign In" : "Register Now"}
                    </button>
                </>
            )}
        </div>
      </div>
    </section>
  );
};

export default Login;