import React from 'react';

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => (
  <details className="group bg-white/70 backdrop-blur border border-brand-taupe rounded-2xl p-6">
      <summary className="cursor-pointer list-none flex items-center justify-between">
          <span className="font-medium text-brand-espresso">{question}</span>
          <span className="text-brand-rose group-open:rotate-45 transition-transform">+</span>
      </summary>
      <p className="text-sm text-brand-text font-light mt-3 leading-relaxed">{answer}</p>
  </details>
);

const FAQ: React.FC = () => {
  return (
    <section className="py-24 max-w-5xl mx-auto px-6 bg-brand-nude">
        <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-brand-rose font-medium tracking-widest text-[10px] uppercase mb-4 block">FAQ</span>
            <h2 className="font-serif text-4xl md:text-5xl text-brand-espresso">Before you buy</h2>
        </div>
        <div className="space-y-4">
            <FAQItem 
              question="✨ What is My Pretty Thoughts™?" 
              answer="My Pretty Thoughts™ is a digital self-growth library designed to help you feel calmer, clearer, and more confident. Everything we create — guides, journals, and digital drops — is made to support emotional clarity, self-trust, and personal growth in a soft, modern, and human way." 
            />
            <FAQItem 
              question="📩 How do I access my purchases?" 
              answer="All purchases are instant digital downloads. After checkout, you’ll receive an email with your access link within minutes. You can download and use your purchases on your phone, tablet, or computer anytime." 
            />
            <FAQItem 
              question="Who is this for?" 
              answer="My Pretty Thoughts™ is for anyone who feels mentally overwhelmed, emotionally sensitive, or ready to grow at their own pace. Whether you’re working on self-love, boundaries, confidence, or emotional balance, our library is created to meet you exactly where you are." 
            />
        </div>
    </section>
  );
};

export default FAQ;