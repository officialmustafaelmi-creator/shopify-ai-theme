import React from 'react';

interface BestsellerProps {
    onBuy?: (item: { title: string; price: string; image?: string }) => void;
}

const Bestseller: React.FC<BestsellerProps> = ({ onBuy }) => {
  return (
    <section id="buy" className="py-24 bg-brand-nude overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
                {/* Left: Product Details */}
                <div className="lg:col-span-5 order-2 lg:order-1 fade-in-up">
                    <span className="text-brand-rose font-medium tracking-widest text-[10px] uppercase mb-4 block">Most Loved</span>
                    <h2 className="font-serif text-4xl md:text-5xl text-brand-espresso leading-tight mb-6">
                        STOP OVERTHINKING<br />
                        <span className="italic text-brand-rose">The PrettyGirl Guide</span>
                    </h2>
                    <ul className="space-y-3 text-sm text-brand-text font-light mb-8">
                        <li className="flex items-start gap-2">
                            <span className="text-brand-rose mt-1">•</span>
                            <span>Calm-your-mind scripts for texts, silence, &amp; “what does it mean?” spirals</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-brand-rose mt-1">•</span>
                            <span>Anxious-attachment reset plan (without acting cold or fake)</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-brand-rose mt-1">•</span>
                            <span>Confidence rebuild exercises you can do in 5 minutes</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-brand-rose mt-1">•</span>
                            <span>Boundaries &amp; detachment—soft, feminine, and grown</span>
                        </li>
                    </ul>
                    <div className="flex items-center gap-4 flex-wrap">
                        <button 
                            onClick={() => onBuy && onBuy({ title: "Stop Overthinking Guide", price: "24.00" })}
                            className="px-8 py-4 bg-brand-espresso text-brand-blush rounded-lg font-medium tracking-wide text-xs uppercase hover:bg-brand-rose transition-all shadow-lg shadow-brand-espresso/20"
                        >
                            Buy Now — $24
                        </button>
                        <span className="text-xs text-brand-text/70 font-light">Instant download • Read on phone • Print anytime</span>
                    </div>
                </div>

                {/* Right: Animated Book Preview */}
                <div className="lg:col-span-7 order-1 lg:order-2 flex justify-center lg:justify-end fade-in-up" style={{ animationDelay: '0.2s' }}>
                    {/* Container matches standard book aspect ratio */}
                    <div className="relative w-[300px] h-[450px] sm:w-[360px] sm:h-[540px] perspective-1000">
                        
                        {/* Page 2 (Furthest Back - Slides out more) */}
                        <div className="absolute top-3 bottom-3 right-0 w-[94%] bg-white rounded-r-lg shadow-md border-r border-t border-b border-brand-taupe/20 z-0 animate-page-slide-far flex flex-col justify-center overflow-hidden">
                             {/* Content aligned to the right edge to be revealed */}
                             <div className="absolute right-0 top-0 bottom-0 w-28 pr-5 flex flex-col justify-center gap-8 opacity-80">
                                 <div>
                                     <div className="h-px w-8 bg-brand-rose mb-2"></div>
                                     <p className="font-serif text-brand-espresso text-[11px] leading-relaxed italic w-40 -ml-12">"Overthinking is your nervous system asking for safety."</p>
                                 </div>
                                 <div>
                                     <p className="font-serif text-brand-espresso text-[11px] leading-relaxed italic w-40 -ml-12">"Choose calm over chaos."</p>
                                 </div>
                                 <span className="text-[8px] uppercase tracking-widest text-brand-text/50">Pg 12</span>
                             </div>
                        </div>

                        {/* Page 1 (Middle - Slides out slightly) */}
                        <div className="absolute top-1.5 bottom-1.5 right-0 w-[97%] bg-white rounded-r-lg shadow-md border-r border-t border-b border-brand-taupe/20 z-10 animate-page-slide flex flex-col justify-center overflow-hidden">
                            {/* Content aligned to the right edge */}
                            <div className="absolute right-0 top-0 bottom-0 w-20 pr-4 flex flex-col justify-center">
                                <div className="border-l-2 border-brand-rose/40 pl-3">
                                    <p className="font-serif text-brand-espresso text-xs leading-relaxed w-32 -ml-10">"Your thoughts are not facts."</p>
                                </div>
                            </div>
                        </div>

                        {/* Cover (Front - Text Based) */}
                        <div className="absolute inset-0 z-20 rounded-r-2xl rounded-l-sm shadow-2xl overflow-hidden bg-[#F2F0EB] flex flex-col items-center justify-center p-8 text-center bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')] border-l-4 border-white/40">
                            
                            <span className="text-[10px] uppercase tracking-[0.3em] text-brand-text/60 mb-12">Vol. 01</span>
                            
                            <h3 className="font-serif text-5xl sm:text-6xl text-brand-espresso leading-[0.9] italic mb-6">
                                Stop<br/>Overthinking
                            </h3>
                            
                            <div className="w-px h-16 bg-brand-rose/50 my-8"></div>
                            
                            <span className="text-[10px] uppercase tracking-widest text-brand-text border border-brand-taupe px-4 py-1.5 rounded-full bg-white/50">
                                Guide
                            </span>

                            {/* Spine/Gloss Effects */}
                            <div className="absolute left-0 top-0 bottom-0 w-6 bg-gradient-to-r from-black/10 to-transparent pointer-events-none z-30"></div>
                            <div className="absolute inset-0 shadow-[inset_0_0_40px_rgba(0,0,0,0.05)] pointer-events-none z-30"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default Bestseller;