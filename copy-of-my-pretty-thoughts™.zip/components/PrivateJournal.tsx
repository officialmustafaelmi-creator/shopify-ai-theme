import React, { useState } from 'react';
import { Book, Save, Calendar, Lock, Globe, FileText, CheckCircle } from 'lucide-react';
import { UserTier } from '../App';

interface Entry {
    id: string;
    date: string;
    prompt: string;
    text: string;
    status: 'draft' | 'published';
}

interface PrivateJournalProps {
    entries: Entry[];
    onSaveEntry: (entry: Entry) => void;
    user: { name: string, tier: UserTier } | null;
    onNavigate: (view: any) => void;
}

const PROMPTS = [
    "What is one thing I am forcing that I need to let flow?",
    "How can I be kinder to my body today?",
    "Write a letter to the version of you from one year ago.",
    "What does my 'soft life' actually look like in detail?",
    "I feel most like myself when..."
];

const PrivateJournal: React.FC<PrivateJournalProps> = ({ entries, onSaveEntry, user, onNavigate }) => {
  const [currentPrompt, setCurrentPrompt] = useState(PROMPTS[0]);
  const [entryText, setEntryText] = useState('');
  const [tab, setTab] = useState<'write' | 'drafts'>('write');

  const handleShuffle = () => {
      const random = PROMPTS[Math.floor(Math.random() * PROMPTS.length)];
      setCurrentPrompt(random);
  };

  const handleSave = (status: 'draft' | 'published') => {
      if (!entryText.trim()) return;
      
      const newEntry: Entry = {
          id: Date.now().toString(),
          date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          prompt: currentPrompt,
          text: entryText,
          status
      };
      
      onSaveEntry(newEntry);
      setEntryText('');
      alert(status === 'draft' ? "Saved to drafts." : "Published to your community profile.");
  };

  if (!user) {
       return (
           <section className="min-h-screen pt-40 bg-brand-nude text-center px-6">
                <div className="max-w-md mx-auto bg-white p-10 rounded-3xl border border-brand-taupe shadow-float">
                    <Lock size={32} className="text-brand-rose mx-auto mb-4" />
                    <h2 className="font-serif text-2xl text-brand-espresso mb-2">Private Journal</h2>
                    <p className="text-brand-text font-light text-sm mb-6">Log in to access your secure, private digital journal.</p>
                    <button onClick={() => onNavigate('login')} className="px-8 py-3 bg-brand-espresso text-brand-blush rounded-full text-xs uppercase tracking-widest hover:bg-brand-rose transition-all">Login to Write</button>
                </div>
           </section>
       );
  }

  return (
    <section className="min-h-screen pt-32 pb-24 bg-brand-paper relative">
        <div className="absolute inset-0 bg-notebook opacity-30 pointer-events-none"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 grid grid-cols-1 md:grid-cols-12 gap-8">
            
            {/* Writing Area */}
            <div className="md:col-span-8">
                <div className="bg-white/80 backdrop-blur-sm rounded-3xl border border-brand-taupe shadow-book p-8 md:p-10">
                    <div className="flex items-center justify-between mb-6">
                         <div className="flex items-center gap-4">
                             <button onClick={() => setTab('write')} className={`text-[10px] uppercase tracking-widest font-medium transition-colors ${tab === 'write' ? 'text-brand-rose' : 'text-brand-text/50 hover:text-brand-espresso'}`}>Write</button>
                             <button onClick={() => setTab('drafts')} className={`text-[10px] uppercase tracking-widest font-medium transition-colors ${tab === 'drafts' ? 'text-brand-rose' : 'text-brand-text/50 hover:text-brand-espresso'}`}>My Drafts</button>
                         </div>
                         <div className="text-brand-text/50 text-xs font-serif italic">
                             {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                         </div>
                    </div>

                    {tab === 'write' ? (
                        <>
                            <div className="mb-6">
                                <p className="font-serif text-xl text-brand-espresso mb-2 leading-relaxed">"{currentPrompt}"</p>
                                <button onClick={handleShuffle} className="text-[10px] text-brand-text uppercase tracking-widest hover:text-brand-rose transition-colors">Shuffle Prompt</button>
                            </div>

                            <textarea 
                                value={entryText}
                                onChange={(e) => setEntryText(e.target.value)}
                                placeholder="Start writing..."
                                className="w-full h-64 bg-transparent border-none focus:ring-0 text-brand-espresso text-sm leading-8 font-light resize-none placeholder:text-brand-taupe placeholder:italic bg-[url('https://www.transparenttextures.com/patterns/paper.png')]"
                                style={{ backgroundImage: 'linear-gradient(#E6E1DE 1px, transparent 1px)', backgroundSize: '100% 2rem', lineHeight: '2rem' }}
                            />
                            
                            <div className="flex justify-between mt-4 pt-6 border-t border-brand-taupe/30">
                                <button 
                                    onClick={() => handleSave('draft')}
                                    disabled={!entryText.trim()}
                                    className="flex items-center gap-2 px-4 py-2 border border-brand-taupe text-brand-text rounded-full text-[10px] uppercase tracking-widest hover:border-brand-rose hover:text-brand-rose transition-all"
                                >
                                    <FileText size={12} /> Save Draft
                                </button>
                                <button 
                                    onClick={() => handleSave('published')}
                                    disabled={!entryText.trim()}
                                    className="flex items-center gap-2 px-6 py-3 bg-brand-espresso text-brand-blush rounded-full text-xs uppercase tracking-widest hover:bg-brand-rose disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                                >
                                    <Globe size={14} /> Publish
                                </button>
                            </div>
                        </>
                    ) : (
                        <div className="space-y-4">
                            {entries.filter(e => e.status === 'draft').length === 0 ? (
                                <p className="text-center text-brand-text/50 italic py-10">No drafts saved.</p>
                            ) : (
                                entries.filter(e => e.status === 'draft').map(entry => (
                                    <div key={entry.id} className="bg-white p-4 rounded-xl border border-brand-taupe cursor-pointer hover:border-brand-rose" onClick={() => { setEntryText(entry.text); setTab('write'); }}>
                                        <p className="font-serif text-brand-espresso mb-2">{entry.prompt}</p>
                                        <p className="text-xs text-brand-text line-clamp-2">{entry.text}</p>
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* Sidebar */}
            <div className="md:col-span-4 space-y-4">
                 <div className="bg-white/50 p-6 rounded-2xl border border-brand-taupe">
                     <h3 className="font-serif text-lg text-brand-espresso mb-4">Published Thoughts</h3>
                     {entries.filter(e => e.status === 'published').length === 0 ? (
                         <p className="text-xs text-brand-text/60 italic">You haven't published anything yet.</p>
                     ) : (
                         <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-brand-taupe">
                             {entries.filter(e => e.status === 'published').map(entry => (
                                 <div key={entry.id} className="bg-white p-4 rounded-xl border border-brand-taupe/40 hover:border-brand-rose/50 transition-colors">
                                     <div className="flex items-center gap-2 text-[9px] uppercase tracking-widest text-brand-text mb-2">
                                         <Calendar size={10} />
                                         {entry.date}
                                         <span className="text-brand-rose flex items-center gap-1 ml-auto"><Globe size={8} /> Public</span>
                                     </div>
                                     <p className="text-xs text-brand-espresso font-medium line-clamp-2 mb-1">{entry.prompt}</p>
                                 </div>
                             ))}
                         </div>
                     )}
                 </div>
                 
                 <div className="bg-brand-rose/10 p-6 rounded-2xl border border-brand-rose/20 text-center">
                     <Lock size={16} className="text-brand-rose mx-auto mb-2" />
                     <p className="text-[10px] text-brand-text leading-relaxed">
                         Drafts are private. Published entries appear on your community profile (coming soon).
                     </p>
                 </div>
            </div>
        </div>
    </section>
  );
};

export default PrivateJournal;