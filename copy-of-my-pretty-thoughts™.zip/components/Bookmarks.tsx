import React, { useState } from 'react';
import { X, Quote, Star, ShoppingBag, MessageSquare, Bookmark as BookmarkIcon } from 'lucide-react';

export interface SavedItem {
  id: string;
  type: 'affirmation' | 'mood' | 'product';
  content: string; // Used for Affirmation text, Mood/Product bg color
  title?: string; // Mood title, Product title
  textColor?: string; // Mood text color
  // Product specific properties
  vol?: string;
  productType?: string;
  price?: string;
}

interface UserReview {
    id: number;
    text: string;
    time: string;
    productTitle: string;
}

interface BookmarksProps {
  savedItems: SavedItem[];
  purchasedItems: SavedItem[];
  userReviews: UserReview[];
  onRemove: (id: string) => void;
  onNavigate: (view: any) => void;
  user: { name: string } | null;
}

const Bookmarks: React.FC<BookmarksProps> = ({ savedItems, purchasedItems, userReviews, onRemove, onNavigate, user }) => {
  const [activeTab, setActiveTab] = useState<'saved' | 'purchased' | 'reviews'>('saved');

  // Helper to translate volume ID to Title for reviews
  const getProductTitle = (volId: string) => {
      const titles: Record<string, string> = {
          'vol1': 'TheDreamGirl',
          'vol2': 'SoftLifeReset',
          'vol3': 'Shadow&Light'
      };
      return titles[volId] || volId;
  };

  return (
    <section className="min-h-screen pt-32 pb-24 bg-brand-nude">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-10 fade-in-up">
            <span className="text-brand-rose font-medium tracking-widest text-[10px] uppercase mb-4 block">Personal Dashboard</span>
            <h2 className="font-serif text-4xl md:text-5xl text-brand-espresso mb-2">
                {user ? `${user.name}'s Desk` : 'Your Collection'}
            </h2>
            <p className="text-sm text-brand-text font-light">Everything you need to romanticize your life.</p>
        </div>

        {/* Dashboard Tabs */}
        <div className="flex justify-center gap-2 mb-12 fade-in-up" style={{ animationDelay: '0.1s' }}>
            <button 
                onClick={() => setActiveTab('saved')}
                className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] uppercase tracking-widest transition-all ${activeTab === 'saved' ? 'bg-brand-espresso text-brand-blush shadow-lg' : 'bg-white border border-brand-taupe text-brand-text hover:border-brand-rose'}`}
            >
                <BookmarkIcon size={14} /> Saved ({savedItems.length})
            </button>
            <button 
                onClick={() => setActiveTab('purchased')}
                className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] uppercase tracking-widest transition-all ${activeTab === 'purchased' ? 'bg-brand-espresso text-brand-blush shadow-lg' : 'bg-white border border-brand-taupe text-brand-text hover:border-brand-rose'}`}
            >
                <ShoppingBag size={14} /> Purchased ({purchasedItems.length})
            </button>
            <button 
                onClick={() => setActiveTab('reviews')}
                className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] uppercase tracking-widest transition-all ${activeTab === 'reviews' ? 'bg-brand-espresso text-brand-blush shadow-lg' : 'bg-white border border-brand-taupe text-brand-text hover:border-brand-rose'}`}
            >
                <MessageSquare size={14} /> Reviews ({userReviews.length})
            </button>
        </div>

        {/* SAVED ITEMS TAB */}
        {activeTab === 'saved' && (
            savedItems.length === 0 ? (
                <div className="text-center py-20 bg-white/50 rounded-3xl border border-brand-taupe border-dashed fade-in-up">
                    <p className="text-brand-text font-light mb-6">Your collection is empty.</p>
                    <button onClick={() => onNavigate('home')} className="px-6 py-3 bg-brand-espresso text-brand-blush rounded-lg font-medium text-xs uppercase hover:bg-brand-rose transition-all">
                    Go Explore
                    </button>
                </div>
            ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 fade-in-up">
                {savedItems.map((item, idx) => (
                <div key={item.id} className="relative group animate-float-slow" style={{ animationDelay: `${idx * 0.2}s` }}>
                    <button 
                    onClick={() => onRemove(item.id)}
                    className="absolute -top-2 -right-2 z-20 w-8 h-8 flex items-center justify-center bg-white rounded-full shadow-md text-brand-espresso hover:text-brand-rose hover:scale-110 transition-all border border-brand-taupe cursor-pointer"
                    aria-label="Remove"
                    >
                    <X size={14} />
                    </button>
                    
                    {item.type === 'affirmation' ? (
                    <div className="bg-brand-paper p-8 rounded-xl shadow-book border border-brand-taupe h-full min-h-[300px] flex flex-col justify-center text-center relative overflow-hidden group-hover:-translate-y-1 transition-transform duration-300">
                        <Quote className="absolute top-6 left-6 text-brand-rose/20" size={40} />
                        <p className="font-serif text-xl text-brand-espresso italic relative z-10 leading-relaxed">"{item.content}"</p>
                        <div className="mt-6 w-12 h-px bg-brand-rose/50 mx-auto"></div>
                    </div>
                    ) : item.type === 'mood' ? (
                    <div className="aspect-[4/5] bg-brand-nude rounded-lg overflow-hidden shadow-book border border-brand-taupe relative group-hover:-translate-y-1 transition-transform duration-300">
                        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                            <rect width="100%" height="100%" fill={item.content} />
                            <text x="50%" y="50%" fontFamily="serif" fontSize="20" fill={item.textColor || "#4A3B39"} textAnchor="middle" dominantBaseline="middle" fontStyle="italic">{item.title}</text>
                        </svg>
                    </div>
                    ) : (
                    <div className="h-full bg-white rounded-xl shadow-sm border border-brand-taupe/50 p-4 group-hover:-translate-y-1 transition-transform duration-300">
                        <div className={`relative aspect-[3/4] ${item.content} rounded-r-lg rounded-l-sm shadow-inner mb-4 overflow-hidden`}>
                            <div className="absolute left-0 top-0 bottom-0 w-4 bg-gradient-to-r from-black/5 to-transparent z-10 pointer-events-none"></div>
                            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]">
                                {item.vol && <span className="text-[8px] uppercase tracking-[0.3em] text-brand-text/60 mb-4">{item.vol}</span>}
                                <h3 className="font-serif text-xl text-brand-espresso leading-none italic mb-2">{item.title}</h3>
                            </div>
                        </div>
                        <div className="text-center">
                            <h4 className="font-serif text-base text-brand-espresso">{item.title}</h4>
                            <span className="text-[10px] uppercase tracking-widest text-brand-text mt-1 block">Saved Item</span>
                        </div>
                    </div>
                    )}
                </div>
                ))}
            </div>
            )
        )}

        {/* PURCHASED ITEMS TAB */}
        {activeTab === 'purchased' && (
            purchasedItems.length === 0 ? (
                <div className="text-center py-20 bg-white/50 rounded-3xl border border-brand-taupe border-dashed fade-in-up">
                    <p className="text-brand-text font-light mb-6">You haven't purchased anything yet.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 fade-in-up">
                    {purchasedItems.map((item) => (
                        <div key={item.id} className="bg-white p-6 rounded-2xl border border-brand-taupe shadow-book flex items-center gap-6">
                            <div className={`w-20 h-24 ${item.content} rounded-r-md rounded-l-sm shadow-inner border border-brand-taupe/30 flex-shrink-0`}></div>
                            <div>
                                <h3 className="font-serif text-lg text-brand-espresso">{item.title}</h3>
                                <div className="flex items-center gap-2 mt-2">
                                    <span className="text-[9px] bg-green-100 text-green-800 px-2 py-0.5 rounded-full uppercase tracking-widest">Owned</span>
                                    <span className="text-[9px] text-brand-text uppercase tracking-widest">PDF Ready</span>
                                </div>
                                <button className="mt-4 text-[10px] border-b border-brand-espresso uppercase tracking-widest hover:text-brand-rose hover:border-brand-rose transition-colors">Download</button>
                            </div>
                        </div>
                    ))}
                </div>
            )
        )}

        {/* REVIEWS TAB */}
        {activeTab === 'reviews' && (
            userReviews.length === 0 ? (
                <div className="text-center py-20 bg-white/50 rounded-3xl border border-brand-taupe border-dashed fade-in-up">
                    <p className="text-brand-text font-light mb-6">You haven't posted any reviews yet.</p>
                    <button onClick={() => onNavigate('club')} className="px-6 py-3 bg-brand-espresso text-brand-blush rounded-lg font-medium text-xs uppercase hover:bg-brand-rose transition-all">
                    Go to Book Club
                    </button>
                </div>
            ) : (
                <div className="space-y-4 max-w-3xl mx-auto fade-in-up">
                    {userReviews.map((review) => (
                        <div key={review.id} className="bg-white p-6 rounded-2xl border border-brand-taupe shadow-sm">
                            <div className="flex items-center justify-between mb-3">
                                <span className="text-xs font-bold text-brand-espresso">{getProductTitle(review.productTitle)}</span>
                                <span className="text-[9px] text-brand-text/60 uppercase tracking-widest">{review.time}</span>
                            </div>
                            <p className="text-sm text-brand-text font-light leading-relaxed">"{review.text}"</p>
                        </div>
                    ))}
                </div>
            )
        )}
      </div>
    </section>
  );
};

export default Bookmarks;