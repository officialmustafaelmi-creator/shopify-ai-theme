import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, MessageSquare, Highlighter, X, Share } from 'lucide-react';

interface ReaderProps {
    product: any;
    progress: number;
    highlights: any[];
    onUpdateProgress: (p: number) => void;
    onAddHighlight: (h: any) => void;
    onBack: () => void;
    user: any;
}

const Reader: React.FC<ReaderProps> = ({ product, progress, highlights, onUpdateProgress, onAddHighlight, onBack, user }) => {
    const [selectedText, setSelectedText] = useState<string | null>(null);
    const [selectionPos, setSelectionPos] = useState({ top: 0, left: 0 });
    const contentRef = useRef<HTMLDivElement>(null);

    // Full Content from "Calm Her Down" PDF
    const content = `
# Introduction

If your brain never stops... if you replay texts, conversations, and decisions over and over again until you're exhausted... if you lie awake at 2 AM analyzing every word you said earlier that day... this guide is for you.

You know that feeling when your mind becomes your worst enemy? When it takes a simple "okay" text and turns it into a dissertation on what you might have done wrong? When you second-guess every choice, every word, until you’re drowning in your own thoughts?

You're not broken. You're not too much. You're not the only one.

Millions of women wake up each day carrying the weight of overthinking like a heavy backpack they can't put down. We've been conditioned to believe that worrying more means caring more, that analyzing every angle makes us responsible, that our hypervigilance keeps us safe.

But here's the truth: your overthinking isn't protecting you anymore. It's stealing your peace, one spiraling thought at a time.

This isn't just another "positive thinking" guide that tells you to "just relax" or "think happy thoughts." This is real, gentle, and designed to help you breathe again.

Over the next five days, we're going to work together to quiet the noise in your head and give you back the mental space you deserve.

By the end of this journey, you'll have:
Mental calm – The ability to sit with your thoughts without them consuming you.
Daily peace tools – Simple, practical techniques you can use anywhere.
Clarity – The power to distinguish between productive thinking and destructive rumination.
Self-trust – Perhaps most importantly, you'll learn to trust yourself again.

Are you ready to stop letting your thoughts hold you hostage? Are you ready to reclaim your peace? Let's begin.

# Day 1: Awareness – What’s Going On?

Before we can change something, we need to understand it. Today isn't about fixing your overthinking – it's about getting curious about it. Think of yourself as a scientist studying your own mind, with compassion instead of judgment.

## Why Your Brain Overthinks

Your overthinking isn't a character flaw or a sign of weakness. It's actually your brain trying to protect you, even when that protection has become a prison.

Here are some reasons why you might overthink:

**Survival Response**
Your brain's primary job is to keep you alive, and it takes this job very seriously. Thousands of years ago, the person who could anticipate every possible danger was more likely to survive. Your overthinking brain is that same survival mechanism working overtime.

**Trauma**
Sometimes overthinking develops as a response to past experiences where you actually weren't safe. Your brain learned that constant vigilance was necessary.

**Control Issues**
Overthinking often stems from a deep need to control outcomes. If you can think through every possible scenario, maybe you can prevent bad things from happening. The painful truth is that most of life is beyond our control.

## Types of Overthinking
**Spiraling**: When one thought leads to another until you're somewhere completely different.
**Second-Guessing**: Constant questioning of your decisions ("What if I'm wrong?").
**Self-Blame**: Turning inward and making everything your fault.

## Journal Prompt
Take a moment to sit with this question, without judgment: "What do I usually overthink the most — and why?"

# Day 2: Interrupt the Spiral

Yesterday you became aware of your overthinking patterns. Today, we're going to learn how to catch them before they carry you away.

## How to Catch the Overthinking Loop
The key isn't to eliminate thoughts. It's about catching the spiral in its early stages.
Most overthinking follows a pattern: The Trigger -> The First Thought -> The Hook -> The Spiral -> The Explosion.
The magic happens when you can catch yourself between steps 2 and 3.

## Early Warning Signs
Physical tension, Emotional shifts, Mental fog, Behavioral changes. When you notice these, pause.

## Technique: "Name It to Tame It"
1. Pause - Take a breath
2. Name - Say "I'm having the thought that..."
3. Observe - Notice how it feels
4. Choose - Decide if it deserves attention

Example: Instead of "He hasn't texted back, he must hate me", try "I'm having the thought that he hates me because he hasn't texted back." This creates distance.

Remember: You are not your thoughts. You are the observer of your thoughts.

# Day 3: Reset Your Inner Voice

Your inner voice is like a radio station playing in the background. If it constantly criticizes, your nervous system responds as if those words are threats.

## Common Inner Voice Patterns
* The Critic: "You can't do anything right."
* The Catastrophizer: "If you mess this up, you'll lose everything."
* The Comparer: "Look at them—they're so successful."
* The Mind Reader: "They're annoyed with you."
* The Fortune Teller: "Why even try? You'll fail."

## Real Affirmations (No Fake Positivity)
Traditional affirmations fail when they feel fake. Try "Real Affirmations":
Instead of "I never make mistakes!", try "I'm learning and growing from my experiences."
Instead of "Everyone loves me!", try "I am worthy of love and connection."

## Practice: Choose 3 Replacement Phrases
Think about your triggers and choose gentler, more realistic phrases to replace the harsh ones.

# Day 4: Control What You Can

Most overthinking is an attempt to control outcomes. We believe thinking harder equals more control. It doesn't.

## The 3 Circles Method
1. **Circle 1: What You Control** (Your actions, responses, effort, words). Focus your energy here.
2. **Circle 2: What You Influence** (Others' opinions, relationships, reputation). Focus on influence, not outcome.
3. **Circle 3: What You Release** (Others' choices, the past, the future, timing). Practice letting go.

When you catch yourself overthinking, ask: "Which circle is this in?"

# Day 5: Build a Mental Calm Routine

Create a personal 10-minute "Mental Peace Ritual". Consistency is key. It signals to your nervous system: "It's safe to relax now."

## Ritual Elements
* Music (Nature sounds, binaural beats)
* Breathwork (4-7-8 breathing, box breathing)
* Journaling (Gratitude, brain dump)
* No-Phone Zones (First 10 mins of day)

## Making It Sustainable
Start tiny. Even 3 minutes counts. Don't worry if you miss a day.

# Bonus: Emergency Calm Toolkit

When anxiety hits hard, your rational brain goes offline. Use these tools to ground yourself.

## 5-4-3-2-1 Sensory Grounding
* 5 things you can SEE
* 4 things you can TOUCH
* 3 things you can HEAR
* 2 things you can SMELL
* 1 thing you can TASTE

## Simple Mantras
"This feeling will pass."
"My thoughts are not facts."
"I control my actions, not the outcomes."
"Right here, right now, I am okay."
"I am not alone in my struggles."

# A Note to You

If you're reading this, you've made the brave choice to prioritize your peace. You are not broken. Your sensitivity is not "too much".

Make this promise: "I will be patient with my process. I will choose progress over perfection. I will speak to myself with love."

You've got this. You've always had this. Now you know it too.
`;

    // Handle Scroll for Progress
    const handleScroll = () => {
        if (contentRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = contentRef.current;
            const p = Math.round(((scrollTop + clientHeight) / scrollHeight) * 100);
            if (p > progress) {
                onUpdateProgress(p);
            }
        }
    };

    // Simulate clicking a paragraph to select it (easier for mock than real text selection)
    const handleParagraphClick = (e: React.MouseEvent, text: string) => {
        if (selectedText === text) {
            setSelectedText(null); // Deselect
        } else {
            setSelectedText(text);
            // Position tooltip near click
            const rect = (e.target as HTMLElement).getBoundingClientRect();
            setSelectionPos({ top: rect.top - 60, left: rect.left });
        }
    };

    const paragraphs = content.split('\n').filter(p => p.trim() !== '');

    const handleHighlight = (color: string) => {
        if (selectedText) {
            onAddHighlight({ text: selectedText, color });
            setSelectedText(null);
        }
    };

    const isHighlighted = (text: string) => {
        const found = highlights.find(h => h.text.trim() === text.trim());
        return found ? found.color : null;
    };

    return (
        <div className="fixed inset-0 bg-brand-paper z-50 flex flex-col">
            {/* Toolbar */}
            <div className="h-16 border-b border-brand-taupe bg-white/80 backdrop-blur flex items-center justify-between px-6 z-10">
                <button onClick={onBack} className="text-brand-text hover:text-brand-espresso">
                    <ArrowLeft size={20} />
                </button>
                <span className="font-serif text-brand-espresso truncate max-w-[200px]">{product.title}</span>
                <div className="flex items-center gap-4 text-xs font-medium text-brand-text">
                    <span>{progress}% Read</span>
                </div>
            </div>

            {/* Content */}
            <div 
                ref={contentRef}
                onScroll={handleScroll}
                className="flex-grow overflow-y-auto p-6 md:p-12 max-w-3xl mx-auto w-full relative"
            >
                <div className="space-y-4 font-serif text-lg md:text-xl text-brand-espresso leading-loose pb-20">
                    {/* Render Title manually since it's injected */}
                    {paragraphs.map((para, idx) => {
                        let className = "cursor-pointer hover:bg-black/5 rounded px-2 transition-colors";
                        let displayContent = para;

                        if (para.startsWith('# ')) {
                            // H1 Header
                            className = "text-4xl font-serif text-brand-espresso mt-16 mb-8 font-medium text-center";
                            displayContent = para.replace('# ', '');
                        } else if (para.startsWith('## ')) {
                            // H2 Header
                            className = "text-2xl font-serif text-brand-espresso mt-10 mb-4 font-medium border-b border-brand-rose/20 pb-2";
                            displayContent = para.replace('## ', '');
                        } else if (para.startsWith('**')) {
                            // Rough bold handling
                             // Standard paragraph styling but we rely on simple markdown-ish logic for now
                        }

                        const hlColor = isHighlighted(para);
                        
                        return (
                            <p 
                                key={idx} 
                                onClick={(e) => !para.startsWith('#') && handleParagraphClick(e, para)}
                                className={`${className} ${hlColor ? hlColor : ''} ${selectedText === para ? 'bg-brand-taupe/30' : ''}`}
                            >
                                {displayContent}
                            </p>
                        );
                    })}
                </div>
            </div>

            {/* Selection Tooltip */}
            {selectedText && (
                <div 
                    className="fixed z-50 bg-brand-espresso text-brand-blush rounded-full shadow-xl px-4 py-2 flex items-center gap-4 animate-fade-in transform -translate-x-1/2 left-1/2 md:left-auto md:translate-x-0"
                    style={{ top: selectionPos.top > 0 ? selectionPos.top : 80, left: selectionPos.top > 0 ? selectionPos.left : '50%' }}
                >
                    <button onClick={() => handleHighlight('bg-brand-rose/30')} className="w-6 h-6 rounded-full bg-brand-rose/50 border border-brand-blush/20 hover:scale-110 transition-transform" />
                    <button onClick={() => handleHighlight('bg-yellow-100')} className="w-6 h-6 rounded-full bg-yellow-200/50 border border-brand-blush/20 hover:scale-110 transition-transform" />
                    <button onClick={() => handleHighlight('bg-green-100')} className="w-6 h-6 rounded-full bg-green-200/50 border border-brand-blush/20 hover:scale-110 transition-transform" />
                    <div className="w-px h-4 bg-white/20"></div>
                    <button onClick={() => alert("Comment feature mock")} className="hover:text-white transition-colors"><MessageSquare size={16} /></button>
                    <button onClick={() => setSelectedText(null)} className="hover:text-white transition-colors"><X size={16} /></button>
                </div>
            )}
        </div>
    );
};

export default Reader;