import React, { useState } from 'react';
import { Heart, Shield, Sparkles, ArrowRight } from 'lucide-react';

interface OnboardingProps {
    onComplete: () => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);

  return (
    <div className="fixed inset-0 bg-brand-nude z-50 flex items-center justify-center p-6">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/paper.png')] opacity-50 pointer-events-none"></div>
        
        <div className="max-w-md w-full bg-white/80 backdrop-blur-xl border border-brand-taupe rounded-3xl p-10 shadow-float relative z-10 text-center fade-in-up">
            
            {step === 1 && (
                <div className="space-y-6">
                    <div className="w-16 h-16 bg-brand-rose/10 rounded-full flex items-center justify-center mx-auto text-brand-rose">
                        <Heart size={24} />
                    </div>
                    <h1 className="font-serif text-3xl text-brand-espresso">Welcome, lovely.</h1>
                    <p className="text-brand-text font-light leading-relaxed">
                        My Pretty Thoughts™ is a sanctuary for the dreamer, the writer, and the woman becoming her own muse.
                    </p>
                    <div className="bg-brand-paper border border-brand-taupe p-4 rounded-xl text-xs text-brand-text/70 italic">
                        "We don't become her by forcing. We become her by choosing calm, choosing clarity, and choosing ourselves."
                    </div>
                    <button onClick={() => setStep(2)} className="w-full py-4 bg-brand-espresso text-brand-blush rounded-xl text-xs uppercase tracking-widest hover:bg-brand-rose transition-colors">
                        Enter the Library
                    </button>
                </div>
            )}

            {step === 2 && (
                <div className="space-y-6 animate-fade-in">
                    <div className="w-16 h-16 bg-brand-espresso/5 rounded-full flex items-center justify-center mx-auto text-brand-espresso">
                        <Shield size={24} />
                    </div>
                    <h2 className="font-serif text-2xl text-brand-espresso">The Vibe Check</h2>
                    <p className="text-sm text-brand-text font-light">
                        To keep this space safe and soft, we ask every member to agree to our community guidelines.
                    </p>
                    <ul className="text-left space-y-3 bg-white/50 p-4 rounded-xl border border-brand-taupe">
                        <li className="flex gap-3 text-xs text-brand-text">
                            <Sparkles size={14} className="text-brand-rose flex-shrink-0" />
                            <span><strong>Be Gentle:</strong> Kindness is our currency. No harshness, hate, or judgment.</span>
                        </li>
                        <li className="flex gap-3 text-xs text-brand-text">
                            <Shield size={14} className="text-brand-rose flex-shrink-0" />
                            <span><strong>Safe Space:</strong> What is shared here, stays here. Respect privacy.</span>
                        </li>
                        <li className="flex gap-3 text-xs text-brand-text">
                            <Heart size={14} className="text-brand-rose flex-shrink-0" />
                            <span><strong>Girls Only:</strong> This is a dedicated space for women to connect and heal.</span>
                        </li>
                    </ul>
                    <div className="flex flex-col gap-3">
                        <button onClick={onComplete} className="w-full py-4 bg-brand-rose text-white rounded-xl text-xs uppercase tracking-widest hover:brightness-110 transition-colors flex items-center justify-center gap-2">
                            I Agree <ArrowRight size={14} />
                        </button>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default Onboarding;