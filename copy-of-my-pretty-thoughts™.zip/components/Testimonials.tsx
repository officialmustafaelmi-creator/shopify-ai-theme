import React from 'react';

const TestimonialCard: React.FC<{ quote: string; name: string }> = ({ quote, name }) => (
  <div className="p-8 rounded-3xl bg-white/70 backdrop-blur border border-brand-taupe shadow-sm">
      <p className="text-sm text-brand-text font-light leading-relaxed">"{quote}"</p>
      <p className="text-xs tracking-widest uppercase text-brand-text/60 mt-4">— {name}</p>
  </div>
);

const Testimonials: React.FC = () => {
  return (
    <section className="py-24 max-w-7xl mx-auto px-6 bg-brand-nude">
        <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="font-serif text-4xl md:text-5xl text-brand-espresso">Real girls. Real relief.</h2>
            <p className="text-sm text-brand-text font-light mt-3">Reviews from our community.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TestimonialCard name="Chloe" quote="I read this in one night and literally felt my chest unclench. I stopped rereading his texts." />
            <TestimonialCard name="Sophia" quote="The attachment reset section changed how I move. I feel grown, not anxious." />
            <TestimonialCard name="Maya" quote="Finally… a soft approach that still makes you feel powerful. Worth it." />
        </div>
    </section>
  );
};

export default Testimonials;