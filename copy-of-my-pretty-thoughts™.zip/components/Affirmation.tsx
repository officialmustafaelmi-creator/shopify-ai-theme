import React, { useState } from 'react';
import { Bookmark, Check } from 'lucide-react';

interface AffirmationProps {
  onSave?: (text: string) => void;
}

const Affirmation: React.FC<AffirmationProps> = ({ onSave }) => {
  const [saved, setSaved] = useState(false);
  const text = "I don't chase, I attract. What belongs to me will simply find me.";

  const handleSave = () => {
    if (onSave) {
        onSave(text);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    }
  };

  return (
    <section className="py-24 bg-brand-espresso relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
        
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
            <span className="inline-block p-3 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 text-brand-rose mb-8">
                <Bookmark size={20} />
            </span>
            
            <h2 className="font-serif text-3xl md:text-5xl text-brand-blush mb-8 leading-tight">
                "I don't chase, I <span className="italic font-light text-brand-rose">attract</span>. 
                What belongs to me will simply find me."
            </h2>
            
            <div className="flex justify-center">
                <button onClick={handleSave} className="group flex flex-col items-center gap-2 cursor-pointer">
                    <span className={`text-xs uppercase tracking-widest transition-colors flex items-center gap-2 ${saved ? 'text-brand-rose' : 'text-brand-taupe group-hover:text-brand-rose'}`}>
                        {saved ? (
                            <>Saved <Check size={12} /></>
                        ) : 'Save to affirmations'}
                    </span>
                    <div className={`h-px transition-all duration-300 ${saved ? 'w-full bg-brand-rose' : 'w-full bg-brand-taupe/30 group-hover:w-1/2'}`}></div>
                </button>
            </div>
        </div>
    </section>
  );
};

export default Affirmation;