import React, { useState } from 'react';
import { MessageCircle, Send, User, Lock, Check, Heart, Sparkles, Ghost } from 'lucide-react';
import { UserTier } from '../App';

interface Review {
    id: number;
    user: string;
    text: string;
    time: string;
    isAnonymous?: boolean;
}

interface ProductData {
    id: string;
    title: string;
    vol: string; // Used as subtitle essentially
    prompt: string;
}

interface BookClubProps {
    products: ProductData[];
    reviews: Record<string, Review[]>;
    onPostReview: (productId: string, text: string, isAnonymous: boolean) => void;
    onEditReview: (productId: string, reviewId: number, text: string) => void;
    user: { name: string, tier: UserTier } | null;
    onNavigate: (view: any) => void;
    onUpgrade: () => void;
}

const BookClub: React.FC<BookClubProps> = ({ products, reviews, onPostReview, onEditReview, user, onNavigate, onUpgrade }) => {
  const [activeTab, setActiveTab] = useState(products[0]?.id || 'vol1');
  const [newComment, setNewComment] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [heartedReviews, setHeartedReviews] = useState<number[]>([]);
  
  // Editing State
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState('');

  const currentProduct = products.find(p => p.id === activeTab);

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;
    if (user.tier !== 'paid') return; // Double check

    onPostReview(activeTab, newComment, isAnonymous);
    setNewComment('');
    setIsAnonymous(false);
  };

  const startEditing = (review: Review) => {
    setEditingId(review.id);
    setEditText(review.text);
  };

  const cancelEditing = () => {
      setEditingId(null);
      setEditText('');
  };

  const saveEdit = () => {
      if (editingId && editText.trim()) {
          onEditReview(activeTab, editingId, editText);
          setEditingId(null);
          setEditText('');
      }
  };

  const toggleHeart = (id: number) => {
      if (heartedReviews.includes(id)) {
          setHeartedReviews(heartedReviews.filter(h => h !== id));
      } else {
          setHeartedReviews([...heartedReviews, id]);
      }
  };

  return (
    <section className="min-h-screen pt-32 pb-24 bg-brand-nude border-t border-brand-taupe relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-brand-rose/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="text-center mb-10 fade-in-up">
           <span className="text-brand-rose font-medium tracking-widest text-[10px] uppercase mb-4 block">Community</span>
           <h2 className="font-serif text-4xl text-brand-espresso mb-4">The Book Club</h2>
           <p className="text-brand-text font-light text-sm max-w-lg mx-auto leading-relaxed">
             Join the conversation. Share your breakthroughs, your favorite pages, and connect with other women doing the work.
           </p>
        </div>

        {/* Product Tabs */}
        <div className="flex flex-wrap justify-center gap-3 md:gap-4 mb-10">
            {products.map(product => (
                <button
                    key={product.id}
                    onClick={() => setActiveTab(product.id)}
                    className={`px-6 py-3 rounded-full text-[10px] md:text-xs uppercase tracking-widest transition-all border ${
                        activeTab === product.id 
                        ? 'bg-brand-espresso text-brand-blush border-brand-espresso shadow-lg transform -translate-y-1' 
                        : 'bg-white text-brand-text border-brand-taupe hover:border-brand-rose hover:text-brand-rose'
                    }`}
                >
                    {product.title}
                </button>
            ))}
        </div>

        {/* Discussion Area */}
        <div className="bg-white/50 backdrop-blur-sm rounded-3xl p-6 md:p-10 border border-brand-taupe shadow-book min-h-[600px] flex flex-col">
            
            {/* Thread Header & Prompt */}
            <div className="border-b border-brand-taupe/50 pb-6 mb-6">
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h3 className="font-serif text-2xl text-brand-espresso italic">{currentProduct?.title}</h3>
                        <p className="text-[10px] text-brand-text uppercase tracking-widest mt-1">Discussion Thread</p>
                    </div>
                    <div className="bg-white p-3 rounded-full shadow-sm border border-brand-taupe/30">
                        <MessageCircle size={20} className="text-brand-rose" />
                    </div>
                </div>
                {/* Daily Prompt */}
                <div className="bg-brand-paper p-4 rounded-xl border border-brand-taupe/40 flex gap-3 items-start">
                    <Sparkles size={16} className="text-brand-rose mt-0.5 flex-shrink-0" />
                    <div>
                        <span className="text-[9px] uppercase tracking-widest text-brand-text/60 block mb-1">Today's Discussion Starter</span>
                        <p className="text-brand-espresso font-serif italic text-sm">{currentProduct?.prompt}</p>
                    </div>
                </div>
            </div>

            {/* Comments List */}
            <div className="flex-grow space-y-6 overflow-y-auto max-h-[400px] pr-2 mb-8 scrollbar-thin scrollbar-thumb-brand-taupe scrollbar-track-transparent">
                {reviews[activeTab]?.map((review) => (
                    <div key={review.id} className="flex gap-4 animate-fade-in group">
                        <div className={`w-8 h-8 rounded-full border flex items-center justify-center flex-shrink-0 shadow-sm ${review.isAnonymous ? 'bg-brand-taupe/20 border-brand-taupe text-brand-text' : 'bg-white border-brand-taupe text-brand-espresso'}`}>
                             {review.isAnonymous ? <Ghost size={14} /> : <User size={14} />}
                        </div>
                        <div className="relative bg-white p-5 rounded-r-2xl rounded-bl-2xl shadow-sm border border-brand-taupe/30 max-w-lg w-full transition-all hover:shadow-md">
                            <div className="flex items-center justify-between mb-2">
                                <span className="text-xs font-bold text-brand-espresso tracking-wide">
                                    {review.isAnonymous ? 'Anonymous Member' : review.user}
                                </span>
                                <div className="flex items-center gap-3">
                                    <span className="text-[9px] text-brand-text/60 uppercase tracking-widest">{review.time}</span>
                                    {/* Visible Edit Text Button */}
                                    {user && user.name === review.user && !review.isAnonymous && editingId !== review.id && (
                                        <button 
                                            onClick={() => startEditing(review)}
                                            className="text-[9px] uppercase tracking-widest text-brand-rose font-medium hover:text-brand-espresso transition-colors"
                                            title="Edit response"
                                        >
                                            Edit
                                        </button>
                                    )}
                                </div>
                            </div>
                            
                            {editingId === review.id ? (
                                <div className="animate-fade-in bg-brand-nude/50 p-2 rounded-xl -ml-2 -mr-2">
                                    <textarea 
                                        value={editText}
                                        onChange={(e) => setEditText(e.target.value)}
                                        className="w-full p-3 rounded-lg bg-white border border-brand-rose focus:outline-none focus:ring-1 focus:ring-brand-rose/20 text-sm text-brand-espresso resize-none"
                                        rows={3}
                                        autoFocus
                                    />
                                    <div className="flex gap-2 justify-end mt-2">
                                        <button 
                                            onClick={cancelEditing} 
                                            className="px-3 py-1.5 rounded-full text-[10px] uppercase tracking-widest text-brand-text hover:bg-brand-taupe/20 transition-colors"
                                        >
                                            Cancel
                                        </button>
                                        <button 
                                            onClick={saveEdit} 
                                            className="px-4 py-1.5 rounded-full bg-brand-espresso text-brand-blush text-[10px] uppercase tracking-widest hover:bg-brand-rose transition-colors flex items-center gap-1"
                                        >
                                            Save <Check size={10} />
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <p className="text-sm text-brand-text font-light leading-relaxed whitespace-pre-wrap">{review.text}</p>
                            )}

                            {/* Heart Reaction */}
                            <button 
                                onClick={() => toggleHeart(review.id)}
                                className="absolute bottom-3 right-3 text-brand-text/40 hover:text-brand-rose transition-colors"
                            >
                                <Heart size={14} fill={heartedReviews.includes(review.id) ? "currentColor" : "none"} className={heartedReviews.includes(review.id) ? "text-brand-rose" : ""} />
                            </button>
                        </div>
                    </div>
                ))}
                {(!reviews[activeTab] || reviews[activeTab].length === 0) && (
                    <div className="text-center py-10 opacity-50">
                        <p className="text-sm text-brand-text italic">No reviews yet. Be the first to share.</p>
                    </div>
                )}
            </div>

            {/* Input Area or Gate */}
            {user ? (
                user.tier === 'paid' ? (
                    <form onSubmit={handlePost} className="relative mt-auto">
                        <div className="flex items-center gap-2 mb-2 px-2">
                             <label className="flex items-center gap-2 cursor-pointer group select-none">
                                <div className={`w-3 h-3 rounded-sm border ${isAnonymous ? 'bg-brand-espresso border-brand-espresso' : 'border-brand-taupe'} flex items-center justify-center transition-colors`}>
                                    {isAnonymous && <Check size={8} className="text-white" />}
                                </div>
                                <input type="checkbox" checked={isAnonymous} onChange={(e) => setIsAnonymous(e.target.checked)} className="hidden" />
                                <span className="text-[10px] uppercase tracking-widest text-brand-text/60 group-hover:text-brand-text">Post Anonymously</span>
                             </label>
                        </div>
                        <input 
                            type="text" 
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder={`Thoughts on ${currentProduct?.title}?`} 
                            className="w-full pl-6 pr-14 py-4 rounded-full bg-white border border-brand-taupe focus:outline-none focus:border-brand-rose focus:ring-1 focus:ring-brand-rose/20 text-sm text-brand-espresso placeholder:text-brand-text/40 shadow-inner"
                        />
                        <button 
                            type="submit" 
                            disabled={!newComment.trim()}
                            className="absolute right-2 bottom-2 p-2 bg-brand-espresso text-brand-blush rounded-full hover:bg-brand-rose disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md"
                        >
                            <Send size={16} />
                        </button>
                    </form>
                ) : (
                    // Free Tier Message
                    <div className="mt-auto p-6 rounded-2xl bg-brand-nude border border-brand-taupe text-center">
                         <Lock size={20} className="text-brand-rose mx-auto mb-3" />
                         <h4 className="font-serif text-lg text-brand-espresso mb-1">Read-Only Access</h4>
                         <p className="text-xs text-brand-text font-light mb-4 max-w-xs mx-auto">
                             Free members can read discussions. Upgrade to the Soft Membership ($6/mo) to post, reply, and access the private audio library.
                         </p>
                         <button onClick={onUpgrade} className="px-6 py-2 bg-brand-espresso text-brand-blush text-[10px] uppercase tracking-widest rounded-full hover:bg-brand-rose transition-colors">
                             Unlock Interaction
                         </button>
                    </div>
                )
            ) : (
                <div onClick={() => onNavigate('login')} className="mt-auto p-4 rounded-2xl bg-white border border-brand-taupe border-dashed text-center cursor-pointer hover:bg-brand-nude transition-colors group">
                    <div className="flex flex-col items-center justify-center gap-2">
                        <Lock size={16} className="text-brand-rose mb-1" />
                        <p className="text-sm text-brand-espresso font-medium">Member Access Only</p>
                        <p className="text-xs text-brand-text font-light">Sign in to join the discussion.</p>
                        <span className="text-[10px] uppercase tracking-widest text-brand-rose mt-2 group-hover:underline">Login Now</span>
                    </div>
                </div>
            )}
        </div>
      </div>
    </section>
  );
};

export default BookClub;