import React, { useState } from 'react';
import { ArrowLeft, Check, Star, Headphones, BookOpen, Layers, Lock, Send, User, Ghost, Heart, Sparkles, Bookmark, Eye } from 'lucide-react';
import { UserTier } from '../App';
import { SavedItem } from '../App';

interface ProductData {
    id: string;
    vol: string;
    title: string;
    type: string;
    price: string;
    description: string;
    bgColor: string;
    image?: string;
    prompt: string;
    audioPrice: string;
    bundlePrice: string;
    isBestseller?: boolean;
}

interface Review {
    id: number;
    user: string;
    text: string;
    time: string;
    isAnonymous?: boolean;
}

interface ProductDetailProps {
    product: ProductData;
    reviews: Review[];
    onPostReview: (text: string, isAnonymous: boolean) => void;
    user: { name: string, tier: UserTier } | null;
    onUpgrade: () => void;
    onBuy: (item: SavedItem) => void;
    onSave: (item: SavedItem) => void;
    onBack: () => void;
    onRead: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, reviews, onPostReview, user, onUpgrade, onBuy, onSave, onBack, onRead }) => {
  const [format, setFormat] = useState<'read' | 'listen' | 'bundle'>('bundle'); // Default to bundle for best value
  const [newComment, setNewComment] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'discuss'>('discuss');
  const [isSaved, setIsSaved] = useState(false);

  // Pricing Logic
  const getPrice = () => {
      switch(format) {
          case 'read': return product.price;
          case 'listen': return product.audioPrice;
          case 'bundle': return product.bundlePrice;
      }
  };

  const handleBuy = () => {
      const itemTitle = format === 'bundle' 
        ? `${product.title} (Bundle)` 
        : format === 'listen' 
            ? `${product.title} (Audio)` 
            : product.title;

      onBuy({
          id: Date.now().toString(),
          type: 'product',
          content: product.bgColor,
          title: itemTitle,
          vol: product.vol,
          productType: product.type,
          price: getPrice(),
          image: product.image
      });
  };

  const handleSave = () => {
    onSave({ 
        id: Date.now().toString(), 
        type: 'product', 
        content: product.bgColor, 
        title: product.title, 
        vol: product.vol, 
        image: product.image 
    });
    setIsSaved(true);
  };

  const handlePost = (e: React.FormEvent) => {
      e.preventDefault();
      if(newComment.trim()) {
          onPostReview(newComment, isAnonymous);
          setNewComment('');
          setIsAnonymous(false);
      }
  };

  return (
    <div className="pt-28 pb-20 bg-brand-nude min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Back Nav */}
        <button onClick={onBack} className="flex items-center gap-2 text-brand-text hover:text-brand-rose transition-colors mb-8 text-xs uppercase tracking-widest font-medium">
            <ArrowLeft size={14} /> Back to Library
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-20">
            {/* Product Image */}
            <div className="lg:col-span-5 flex justify-center lg:justify-start">
                <div className={`relative w-full max-w-md aspect-[3/4] ${product.bgColor} rounded-r-2xl rounded-l-md shadow-book border border-brand-taupe/50 overflow-hidden group`}>
                     <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black/5 to-transparent z-10 pointer-events-none"></div>
                     
                     {/* Bookmark Button Overlay */}
                     <button 
                        onClick={handleSave}
                        className={`absolute top-6 left-6 z-20 w-10 h-10 flex items-center justify-center rounded-full backdrop-blur-md border border-brand-taupe/20 transition-all duration-300 ${isSaved ? 'bg-brand-rose text-white shadow-glow' : 'bg-white/60 text-brand-espresso hover:bg-brand-rose hover:text-white'}`}
                    >
                        {isSaved ? <Check size={16} /> : <Bookmark size={16} />}
                    </button>

                    {product.image ? (
                        <img 
                            src={product.image} 
                            alt={product.title} 
                            className="absolute inset-0 w-full h-full object-cover"
                        />
                    ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]">
                            <span className="text-[10px] uppercase tracking-[0.3em] text-brand-text/60 mb-8">{product.vol}</span>
                            <h3 className="font-serif text-4xl lg:text-5xl text-brand-espresso leading-none italic mb-4">{product.title}</h3>
                            <div className="w-px h-16 bg-brand-rose/50 my-6"></div>
                            <span className="text-[10px] uppercase tracking-widest text-brand-text border border-brand-taupe px-4 py-1.5 rounded-full bg-white/50">{product.type}</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Product Info */}
            <div className="lg:col-span-7 flex flex-col">
                <div className="mb-6">
                    <h1 className="font-serif text-4xl text-brand-espresso mb-2">{product.title} Guide</h1>
                    <div className="flex items-center gap-2 text-brand-text text-sm mb-4">
                        <div className="flex text-brand-rose"><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /></div>
                        <span>4.9 (128 reviews)</span>
                    </div>
                    <p className="text-brand-text leading-relaxed font-light">{product.description}</p>
                </div>

                {/* Format Selector */}
                <div className="bg-white/50 rounded-2xl p-6 border border-brand-taupe mb-8">
                    <span className="text-[10px] uppercase tracking-widest text-brand-text/70 mb-4 block">Select Format</span>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <button 
                            onClick={() => setFormat('read')}
                            className={`relative p-4 rounded-xl border text-left transition-all ${format === 'read' ? 'bg-white border-brand-espresso ring-1 ring-brand-espresso' : 'bg-transparent border-brand-taupe hover:border-brand-rose'}`}
                        >
                            <div className="flex items-center gap-2 mb-2 text-brand-espresso">
                                <BookOpen size={16} />
                                <span className="font-serif italic">Read</span>
                            </div>
                            <p className="text-lg font-medium text-brand-espresso">${product.price}</p>
                            <p className="text-[10px] text-brand-text mt-1">PDF Download</p>
                        </button>

                        <button 
                            onClick={() => setFormat('listen')}
                            className={`relative p-4 rounded-xl border text-left transition-all ${format === 'listen' ? 'bg-white border-brand-espresso ring-1 ring-brand-espresso' : 'bg-transparent border-brand-taupe hover:border-brand-rose'}`}
                        >
                            <div className="flex items-center gap-2 mb-2 text-brand-espresso">
                                <Headphones size={16} />
                                <span className="font-serif italic">Listen</span>
                            </div>
                            <p className="text-lg font-medium text-brand-espresso">${product.audioPrice}</p>
                            <p className="text-[10px] text-brand-text mt-1">Audiobook</p>
                        </button>

                        <button 
                            onClick={() => setFormat('bundle')}
                            className={`relative p-4 rounded-xl border text-left transition-all overflow-hidden ${format === 'bundle' ? 'bg-brand-rose/5 border-brand-rose ring-1 ring-brand-rose' : 'bg-transparent border-brand-taupe hover:border-brand-rose'}`}
                        >
                            {/* Best Value Badge */}
                            <div className="absolute top-0 right-0 bg-brand-rose text-white text-[8px] uppercase tracking-widest px-2 py-1 rounded-bl-lg font-medium">Best Value</div>
                            
                            <div className="flex items-center gap-2 mb-2 text-brand-espresso">
                                <Layers size={16} />
                                <span className="font-serif italic">Bundle</span>
                            </div>
                            <p className="text-lg font-medium text-brand-espresso">${product.bundlePrice}</p>
                            <p className="text-[10px] text-brand-text mt-1">PDF + Audio</p>
                        </button>
                    </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 mt-auto">
                    <button onClick={handleBuy} className="flex-grow py-4 bg-brand-espresso text-brand-blush rounded-xl text-xs uppercase tracking-widest font-medium hover:bg-brand-rose transition-all shadow-lg flex items-center justify-center gap-2">
                        Purchase — ${getPrice()}
                    </button>
                    <button onClick={onRead} className="px-8 py-4 bg-brand-rose/10 text-brand-rose rounded-xl text-xs uppercase tracking-widest font-medium hover:bg-brand-rose hover:text-white transition-all flex items-center gap-2">
                        <Eye size={16} /> Preview / Read
                    </button>
                </div>
            </div>
        </div>

        {/* DISCUSSION & DETAILS TABS */}
        <div className="border-t border-brand-taupe pt-10">
            <div className="flex gap-8 mb-8 border-b border-brand-taupe/30 pb-2">
                <button 
                    onClick={() => setActiveTab('discuss')}
                    className={`pb-2 text-xs uppercase tracking-widest transition-colors ${activeTab === 'discuss' ? 'text-brand-espresso border-b-2 border-brand-espresso' : 'text-brand-text hover:text-brand-rose'}`}
                >
                    Reader Discussion
                </button>
                <button 
                    onClick={() => setActiveTab('details')}
                    className={`pb-2 text-xs uppercase tracking-widest transition-colors ${activeTab === 'details' ? 'text-brand-espresso border-b-2 border-brand-espresso' : 'text-brand-text hover:text-brand-rose'}`}
                >
                    Book Details
                </button>
            </div>

            {activeTab === 'discuss' && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
                    <div className="md:col-span-8">
                         {/* Prompt Card */}
                         <div className="bg-brand-paper p-6 rounded-2xl border border-brand-taupe mb-8 flex gap-4">
                            <div className="p-3 bg-white rounded-full h-fit border border-brand-taupe/50 shadow-sm text-brand-rose">
                                <Sparkles size={20} />
                            </div>
                            <div>
                                <span className="text-[10px] uppercase tracking-widest text-brand-text/60 block mb-1">Starter Prompt</span>
                                <p className="font-serif text-xl text-brand-espresso italic leading-relaxed">"{product.prompt}"</p>
                            </div>
                         </div>

                         {/* Reviews List */}
                         <div className="space-y-6 mb-10">
                            {reviews.length > 0 ? reviews.map(review => (
                                <div key={review.id} className="bg-white p-6 rounded-2xl border border-brand-taupe/50 shadow-sm flex gap-4">
                                     <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${review.isAnonymous ? 'bg-brand-taupe/20 text-brand-text' : 'bg-brand-espresso text-brand-blush'}`}>
                                         {review.isAnonymous ? <Ghost size={16} /> : <User size={16} />}
                                     </div>
                                     <div className="flex-grow">
                                         <div className="flex items-center justify-between mb-2">
                                             <span className="font-bold text-xs text-brand-espresso">{review.isAnonymous ? 'Anonymous' : review.user}</span>
                                             <span className="text-[9px] text-brand-text uppercase tracking-widest">{review.time}</span>
                                         </div>
                                         <p className="text-sm text-brand-text font-light leading-relaxed">{review.text}</p>
                                     </div>
                                </div>
                            )) : (
                                <p className="text-center text-brand-text/50 italic py-10">Be the first to share your thoughts.</p>
                            )}
                         </div>

                         {/* Input Area (Gated) */}
                         {user ? (
                             user.tier === 'paid' ? (
                                <form onSubmit={handlePost} className="bg-white p-6 rounded-2xl border border-brand-taupe shadow-lg">
                                    <h4 className="font-serif text-lg text-brand-espresso mb-4">Join the conversation</h4>
                                    <textarea 
                                        value={newComment}
                                        onChange={(e) => setNewComment(e.target.value)}
                                        placeholder="Share your breakthrough..."
                                        className="w-full p-4 rounded-xl bg-brand-nude border border-brand-taupe focus:outline-none focus:border-brand-rose text-sm mb-4 resize-none h-24"
                                    />
                                    <div className="flex items-center justify-between">
                                        <label className="flex items-center gap-2 cursor-pointer select-none">
                                            <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${isAnonymous ? 'bg-brand-espresso border-brand-espresso' : 'border-brand-taupe bg-white'}`}>
                                                {isAnonymous && <Check size={10} className="text-white" />}
                                            </div>
                                            <input type="checkbox" checked={isAnonymous} onChange={e => setIsAnonymous(e.target.checked)} className="hidden" />
                                            <span className="text-[10px] uppercase tracking-widest text-brand-text">Post Anonymously</span>
                                        </label>
                                        <button type="submit" disabled={!newComment.trim()} className="px-6 py-2 bg-brand-espresso text-brand-blush rounded-full text-xs uppercase tracking-widest hover:bg-brand-rose transition-colors disabled:opacity-50">
                                            Post Comment
                                        </button>
                                    </div>
                                </form>
                             ) : (
                                <div className="bg-brand-nude p-8 rounded-2xl border border-brand-taupe text-center">
                                    <Lock size={24} className="text-brand-rose mx-auto mb-4" />
                                    <h3 className="font-serif text-xl text-brand-espresso mb-2">Soft Membership Required</h3>
                                    <p className="text-sm text-brand-text font-light mb-6 max-w-md mx-auto">Join the club to unlock discussions, reply to others, and access the private audio library.</p>
                                    <button onClick={onUpgrade} className="px-8 py-3 bg-brand-espresso text-brand-blush rounded-full text-xs uppercase tracking-widest hover:bg-brand-rose transition-colors">
                                        Upgrade — $6/mo
                                    </button>
                                </div>
                             )
                         ) : (
                            <div className="p-8 border border-brand-taupe border-dashed rounded-2xl text-center">
                                <p className="text-brand-text text-sm mb-4">Please login to join the discussion.</p>
                            </div>
                         )}
                    </div>
                    
                    {/* Sidebar Info */}
                    <div className="md:col-span-4 space-y-6">
                        <div className="bg-white p-6 rounded-2xl border border-brand-taupe">
                            <h4 className="font-serif text-lg text-brand-espresso mb-2">Community Guidelines</h4>
                            <ul className="space-y-2 text-xs text-brand-text font-light">
                                <li className="flex gap-2"><Heart size={12} className="text-brand-rose flex-shrink-0" /> Be gentle with each other.</li>
                                <li className="flex gap-2"><Heart size={12} className="text-brand-rose flex-shrink-0" /> What is shared here, stays here.</li>
                                <li className="flex gap-2"><Heart size={12} className="text-brand-rose flex-shrink-0" /> Take what resonates, leave the rest.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            )}
            
            {activeTab === 'details' && (
                <div className="max-w-2xl">
                    <h3 className="font-serif text-2xl text-brand-espresso mb-4">Inside this volume</h3>
                    <p className="text-brand-text leading-relaxed font-light mb-6">
                        This digital guide is formatted for use on iPad (GoodNotes, Notability) or for printing at home. 
                        It includes over 50 pages of curated content designed to shift your mindset from lack to abundance, 
                        and from anxiety to peace.
                    </p>
                    <ul className="list-disc pl-5 space-y-2 text-sm text-brand-text font-light">
                        <li>Instant PDF Download</li>
                        <li>Hyperlinked tabs for easy navigation</li>
                        <li>30+ Journaling Prompts</li>
                        <li>Printable Affirmation Cards</li>
                    </ul>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;