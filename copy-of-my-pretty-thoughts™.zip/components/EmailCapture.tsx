import React from 'react';

const EmailCapture: React.FC = () => {
  return (
    <section className="py-24 bg-brand-espresso relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
            <span className="inline-block px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 text-brand-rose mb-6 text-[10px] tracking-widest uppercase">Free Gift</span>
            <h2 className="font-serif text-3xl md:text-5xl text-brand-blush mb-4">Get the 3‑Minute Calm Audio</h2>
            <p className="text-sm text-brand-blush/80 font-light mb-10">A gentle audio reset to listen to when you feel overwhelmed. No spam. Just pretty thoughts.</p>

            <form className="max-w-lg mx-auto flex flex-col sm:flex-row gap-3" onSubmit={(e) => e.preventDefault()}>
                <input type="email" required placeholder="Your email" className="w-full px-5 py-4 rounded-xl bg-white/10 border border-white/20 text-brand-blush placeholder:text-brand-blush/50 focus:outline-none focus:ring-2 focus:ring-brand-rose/60" />
                <button type="submit" className="px-7 py-4 rounded-xl bg-brand-rose text-white text-xs tracking-widest uppercase font-medium hover:brightness-110 transition-all">Send it</button>
            </form>
            <p className="text-xs text-brand-blush/60 font-light mt-4">We'll email you the audio link instantly.</p>
        </div>
    </section>
  );
};

export default EmailCapture;