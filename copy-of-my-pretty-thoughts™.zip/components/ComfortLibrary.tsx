import React from 'react';
import { Play, Pause, Headphones, Clock, Lock, ShoppingBag } from 'lucide-react';
import { Track } from './AudioPlayer';

const TRACKS: Track[] = [
    { id: '1', title: 'Morning Alignment', duration: '3:00', coverColor: 'bg-[#F2F0EB]' },
    { id: '2', title: 'Release The Day', duration: '5:45', coverColor: 'bg-[#FDF2F5]' },
    { id: '3', title: 'Anxiety SOS', duration: '2:30', coverColor: 'bg-[#F5F5F4]' },
    { id: '4', title: 'Walking Meditation', duration: '10:00', coverColor: 'bg-[#E6E1DE]' },
    { id: '5', title: 'Confidence Boost', duration: '4:15', coverColor: 'bg-[#EADBDD]' },
];

interface ComfortLibraryProps {
    onPlay: (track: Track) => void;
    currentTrackId?: string;
    purchasedTitles: string[];
    onUnlock: (track: Track) => void;
}

const ComfortLibrary: React.FC<ComfortLibraryProps> = ({ onPlay, currentTrackId, purchasedTitles = [], onUnlock }) => {
  return (
    <section className="min-h-screen pt-32 pb-24 bg-brand-nude">
        <div className="max-w-4xl mx-auto px-6">
            <div className="text-center mb-16 fade-in-up">
                <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-brand-taupe mb-4 text-brand-rose text-[10px] uppercase tracking-widest">
                    <Headphones size={12} />
                    Audio Library
                </span>
                <h2 className="font-serif text-4xl text-brand-espresso mb-4">The Comfort <span className="italic text-brand-rose">Collection</span></h2>
                <p className="text-brand-text font-light text-sm max-w-lg mx-auto">
                    Short, gentle audio tracks designed to shift your state in minutes. 
                    Unlock individual sessions to build your personal peace toolkit.
                </p>
            </div>

            <div className="grid gap-4 fade-in-up relative" style={{ animationDelay: '0.1s' }}>
                {TRACKS.map((track) => {
                    const isUnlocked = purchasedTitles.includes(track.title);

                    return (
                        <div 
                            key={track.id} 
                            className={`group p-4 bg-white rounded-2xl border transition-all flex items-center gap-4 cursor-pointer hover:shadow-lg hover:-translate-y-1 ${currentTrackId === track.id ? 'border-brand-rose shadow-md' : 'border-brand-taupe hover:border-brand-rose/50'} ${!isUnlocked ? 'bg-white/80' : ''}`}
                            onClick={() => isUnlocked ? onPlay(track) : onUnlock(track)}
                        >
                            <div className={`w-12 h-12 rounded-xl ${track.coverColor} flex items-center justify-center text-brand-espresso shadow-inner relative overflow-hidden`}>
                                {currentTrackId === track.id ? (
                                    <div className="flex gap-0.5 items-end h-4">
                                        <div className="w-1 bg-brand-espresso animate-[bounce_1s_infinite] h-2"></div>
                                        <div className="w-1 bg-brand-espresso animate-[bounce_1.2s_infinite] h-4"></div>
                                        <div className="w-1 bg-brand-espresso animate-[bounce_0.8s_infinite] h-3"></div>
                                    </div>
                                ) : (
                                    isUnlocked ? <Play size={16} fill="currentColor" className="opacity-50 group-hover:opacity-100 transition-opacity" /> : <Lock size={16} className="text-brand-text/40" />
                                )}
                            </div>
                            
                            <div className="flex-grow">
                                <h3 className={`font-serif text-lg ${currentTrackId === track.id ? 'text-brand-rose' : 'text-brand-espresso group-hover:text-brand-rose'} transition-colors`}>{track.title}</h3>
                                <p className="text-xs text-brand-text font-light">Guided Session</p>
                            </div>

                            <div className="flex items-center gap-2 text-brand-text/50 text-xs font-medium tracking-wide mr-2">
                                <Clock size={12} />
                                {track.duration}
                            </div>
                            
                            {isUnlocked ? (
                                <button className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${currentTrackId === track.id ? 'bg-brand-rose text-white' : 'bg-brand-nude text-brand-espresso group-hover:bg-brand-espresso group-hover:text-white'}`}>
                                    {currentTrackId === track.id ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" />}
                                </button>
                            ) : (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onUnlock(track); }} 
                                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-brand-espresso text-brand-blush text-[10px] uppercase tracking-widest font-medium hover:bg-brand-rose hover:text-white transition-all shadow-md group-hover:scale-105"
                                >
                                    Unlock $4
                                </button>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    </section>
  );
};

export default ComfortLibrary;