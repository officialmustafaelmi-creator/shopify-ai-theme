import React from 'react';

const Manifesto: React.FC = () => {
  return (
    <section id="manifesto" className="py-24 max-w-4xl mx-auto px-6 bg-brand-nude">
        <div className="bg-white/70 backdrop-blur border border-brand-taupe rounded-3xl p-10 md:p-14 shadow-float">
            <span className="text-brand-rose font-medium tracking-widest text-[10px] uppercase mb-4 block">My Pretty Thoughts™</span>
            <h2 className="font-serif text-3xl md:text-4xl text-brand-espresso mb-6">The manifesto</h2>
            <p className="text-sm text-brand-text font-light leading-relaxed">
                We don’t become “her” by forcing. We become her by choosing calm, choosing clarity,
                and choosing ourselves—softly and consistently. Pretty thoughts. Gentle habits. Grown boundaries.
            </p>
        </div>
    </section>
  );
};

export default Manifesto;