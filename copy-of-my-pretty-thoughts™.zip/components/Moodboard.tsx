import React from 'react';

interface MoodImageProps {
    color: string;
    text: string;
    hasSave?: boolean;
    textColor?: string;
    onSave?: (item: { content: string; title: string; textColor: string }) => void;
}

const MoodImage: React.FC<MoodImageProps> = ({ color, text, hasSave, textColor = "#4A3B39", onSave }) => (
  <div className="aspect-[4/5] bg-brand-nude rounded-lg overflow-hidden relative group">
    <div className="absolute inset-0 bg-brand-espresso/10 group-hover:bg-transparent transition-all pointer-events-none z-10"></div>
    {/* SVG Placeholder to match the prompt's exact style */}
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
      <rect width="100%" height="100%" fill={color} />
      <text x="50%" y="50%" fontFamily="serif" fontSize="20" fill={textColor} textAnchor="middle" dominantBaseline="middle" fontStyle="italic">{text}</text>
    </svg>
    {hasSave && (
      <button 
        onClick={() => onSave && onSave({ content: color, title: text, textColor })}
        className="absolute bottom-4 left-4 bg-white/90 px-3 py-1.5 rounded text-[10px] uppercase tracking-wide opacity-0 group-hover:opacity-100 transition-opacity text-brand-espresso z-20 hover:bg-brand-rose hover:text-white cursor-pointer"
      >
        Save
      </button>
    )}
  </div>
);

interface MoodboardProps {
    onSave?: (item: any) => void;
}

const Moodboard: React.FC<MoodboardProps> = ({ onSave }) => {
  return (
    <section className="py-24 bg-white">
        <div className="flex flex-col items-center justify-center mb-12">
            <h2 className="font-serif text-3xl text-brand-espresso">The <span className="italic text-brand-rose">Moodboard</span></h2>
            <p className="text-xs text-brand-text mt-2 tracking-widest uppercase">@myprettythoughts</p>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-4">
             <MoodImage color="#EADBDD" text="Library Date" textColor="#9d174d" hasSave onSave={onSave} />
             <div className="mt-8 md:mt-0">
               <MoodImage color="#F2E8E4" text="Coffee" textColor="#4A3B39" />
             </div>
             <MoodImage color="#F9FAFB" text="Writing" textColor="#D68C93" />
             <div className="mt-8 md:mt-0">
               <MoodImage color="#FCE7F3" text="Flowers" textColor="#831843" hasSave onSave={onSave} />
             </div>
        </div>
    </section>
  );
};

export default Moodboard;