
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import Bestseller from './components/Bestseller';
import Library from './components/Library';
import ProductDetail from './components/ProductDetail';
import Affirmation from './components/Affirmation';
import Moodboard from './components/Moodboard';
import Testimonials from './components/Testimonials';
import BookClub from './components/BookClub';
import EmailCapture from './components/EmailCapture';
import FAQ from './components/FAQ';
import Manifesto from './components/Manifesto';
import Footer from './components/Footer';
import Login from './components/Login';
import AudioPlayer, { Track } from './components/AudioPlayer';
import ComfortLibrary from './components/ComfortLibrary';
import PrivateJournal from './components/PrivateJournal';
import Onboarding from './components/Onboarding';
import Profile from './components/Profile';
import Reader from './components/Reader';

// GLOBAL TYPES
export type UserTier = 'free' | 'paid';

export interface UserProfile {
    name: string;
    displayName: string;
    bio: string;
    tier: UserTier;
    streak: number;
    joined: string;
    isShopifySynced?: boolean;
    shopifyId?: string;
}

export interface SavedItem {
  id: string;
  type: 'affirmation' | 'mood' | 'product';
  content: string; 
  title?: string;
  textColor?: string;
  vol?: string;
  productType?: string;
  price?: string;
  image?: string;
}

export const PRODUCTS = [
  {
    id: 'vol1',
    vol: 'Vol. 01',
    title: 'Stop Overthinking',
    type: 'Guide',
    price: '24.00',
    description: 'A 5-Day Guide to Stop Overthinking & Reclaim Your Peace. Learn to interrupt the spiral, reset your inner voice, and build a sustainable mental calm routine.',
    bgColor: 'bg-[#F2F0EB]',
    prompt: 'What is one thought you are ready to release today?',
    audioPrice: '29.00',
    bundlePrice: '32.00',
    tags: ['Anxiety Relief', 'Mindset', 'Self-Trust'],
    trending: 'Bestseller'
  },
  {
    id: 'vol2',
    vol: 'Vol. 02',
    title: 'SoftLifeReset',
    type: 'Planner',
    price: '28.00',
    description: 'Organize your days with ease, not pressure. Features gentle time-blocking, meal ideas, and boundary-setting worksheets designed for the recovering perfectionist.',
    bgColor: 'bg-[#FDF2F5]',
    prompt: 'Which boundary feels hardest to set right now?',
    audioPrice: '33.00',
    bundlePrice: '36.00',
    isBestseller: true,
    tags: ['Organization', 'Boundaries', 'Anxiety Relief'],
    trending: 'Trending Now'
  },
  {
    id: 'vol3',
    vol: 'Vol. 03',
    title: 'Shadow&Light',
    type: 'Workbook',
    price: '32.00',
    description: 'Deep dive into your subconscious. Guided shadow work questions, inner child healing, and forgiveness exercises to help you release what no longer serves you.',
    bgColor: 'bg-[#F5F5F4]',
    prompt: 'What are you ready to forgive yourself for?',
    audioPrice: '37.00',
    bundlePrice: '40.00',
    tags: ['Shadow Work', 'Healing', 'Journaling'],
    trending: 'Community Favorite'
  },
];

const INITIAL_REVIEWS = {
  vol1: [
    { id: 1, user: "Bella", text: "The 'Name It to Tame It' technique literally stopped my spiral yesterday. Life saver.", time: "2h ago", isAnonymous: false },
    { id: 2, user: "Sophia", text: "Day 3 hit hard. I didn't realize how mean my inner voice was until I read this.", time: "5h ago", isAnonymous: false },
  ],
  vol2: [
    { id: 3, user: "Chloe", text: "My Sundays are sacred now. The reset checklist is everything.", time: "1d ago", isAnonymous: false },
    { id: 4, user: "Ava", text: "Obsessed with the layout. Very clean.", time: "2d ago", isAnonymous: false },
  ],
  vol3: [
    { id: 5, user: "Maya", text: "Heavy work, but necessary. Cried through page 12 in a good way.", time: "3d ago", isAnonymous: false },
    { id: 6, user: "Elena", text: "The shadow work prompts are intense. Take your time with this one.", time: "4d ago", isAnonymous: false },
  ]
};

export default function App() {
  const [onboardingComplete, setOnboardingComplete] = useState(false);
  const [currentView, setCurrentView] = useState<'home' | 'club' | 'login' | 'comfort' | 'journal' | 'library' | 'product' | 'profile' | 'read'>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [savedItems, setSavedItems] = useState<SavedItem[]>([]);
  const [purchasedItems, setPurchasedItems] = useState<SavedItem[]>([]);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [reviews, setReviews] = useState<Record<string, { id: number, user: string, text: string, time: string, isAnonymous: boolean }[]>>(INITIAL_REVIEWS);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [journalEntries, setJournalEntries] = useState<{id: string, date: string, prompt: string, text: string, status: 'draft' | 'published'}[]>([]);
  const [readingProgress, setReadingProgress] = useState<Record<string, number>>({}); 
  const [highlights, setHighlights] = useState<Record<string, {text: string, color: string, note?: string}[]>>({});
  const [notifications, setNotifications] = useState<{id: string, text: string, read: boolean}[]>([
      { id: '1', text: 'Welcome to the club! Start your reading streak.', read: false }
  ]);

  useEffect(() => {
    // 1. Load Local State
    const storedReviews = localStorage.getItem('mpt_reviews');
    if (storedReviews) setReviews({ ...INITIAL_REVIEWS, ...JSON.parse(storedReviews) });
    
    const isOb = localStorage.getItem('mpt_onboarding');
    if (isOb === 'true') setOnboardingComplete(true);

    // 2. Shopify Integration Check
    const shopifyCustomer = (window as any).Shopify?.customer || (window as any).ShopifyCustomData?.customer;
    
    if (shopifyCustomer && shopifyCustomer.email) {
        handleShopifyAutoLogin(shopifyCustomer);
    } else {
        const activeSessionUser = localStorage.getItem('mpt_active_session');
        if (activeSessionUser) handleLogin(activeSessionUser, false);
    }
  }, []);

  const handleShopifyAutoLogin = (customer: { email: string, first_name?: string, id?: string }) => {
    const username = customer.email;
    const db = JSON.parse(localStorage.getItem('mpt_users') || '{}');
    
    if (!db[username]) {
        db[username] = {
            username,
            displayName: customer.first_name || 'Reader',
            tier: 'free',
            joined: new Date().toISOString(),
            isShopifySynced: true,
            shopifyId: customer.id,
            savedItems: [],
            purchasedItems: [],
            journalEntries: []
        };
        localStorage.setItem('mpt_users', JSON.stringify(db));
    } else {
        // Ensure synched flag is set if they previously registered manually
        if (!db[username].isShopifySynced) {
            db[username].isShopifySynced = true;
            db[username].shopifyId = customer.id;
            localStorage.setItem('mpt_users', JSON.stringify(db));
        }
    }
    
    handleLogin(username, false);
  };

  const completeOnboarding = () => {
      setOnboardingComplete(true);
      localStorage.setItem('mpt_onboarding', 'true');
  };

  const persistUserData = (username: string, saved: SavedItem[], bought: SavedItem[], tier: UserTier, entries: any[], profileData: Partial<UserProfile> = {}) => {
    const db = JSON.parse(localStorage.getItem('mpt_users') || '{}');
    const existingUser = db[username] || {};
    
    db[username] = { 
        ...existingUser, 
        savedItems: saved, 
        purchasedItems: bought,
        tier: tier,
        journalEntries: entries,
        ...profileData
    };
    
    localStorage.setItem('mpt_users', JSON.stringify(db));
  };

  const handleLogin = (name: string, shouldRedirect = true) => {
    const db = JSON.parse(localStorage.getItem('mpt_users') || '{}');
    const userData = db[name];
    
    if (userData) {
        const userTier = userData.tier || 'free'; 
        setUser({ 
            name, 
            displayName: userData.displayName || name,
            bio: userData.bio || 'Just a girl becoming her own muse.',
            tier: userTier,
            streak: userData.streak || 0,
            joined: userData.joined || new Date().toISOString(),
            isShopifySynced: userData.isShopifySynced || false,
            shopifyId: userData.shopifyId
        });
        setSavedItems(userData.savedItems || []);
        setPurchasedItems(userData.purchasedItems || []);
        setJournalEntries(userData.journalEntries || []);
        
        localStorage.setItem('mpt_active_session', name);
        if (shouldRedirect) setCurrentView('profile'); 
    }
  };

  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
      if (user) {
          const newUser = { ...user, ...updated };
          setUser(newUser);
          persistUserData(user.name, savedItems, purchasedItems, user.tier, journalEntries, updated);
      }
  };

  const handleUpgrade = () => {
    if (user) {
        const updatedUser = { ...user, tier: 'paid' as UserTier };
        setUser(updatedUser);
        persistUserData(user.name, savedItems, purchasedItems, 'paid', journalEntries);
        alert("Welcome to the Soft Membership!");
    } else {
        setCurrentView('login');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setSavedItems([]);
    setPurchasedItems([]);
    setJournalEntries([]);
    localStorage.removeItem('mpt_active_session');
    setCurrentView('home');
    setCurrentTrack(null);
  };

  const handleAddReview = (productId: string, text: string, isAnonymous: boolean) => {
    if (!user) return;
    const newReview = { id: Date.now(), user: user.displayName, text, time: "Just now", isAnonymous };
    const updatedReviews = { ...reviews, [productId]: [newReview, ...(reviews[productId] || [])] };
    setReviews(updatedReviews);
    localStorage.setItem('mpt_reviews', JSON.stringify(updatedReviews));
  };

  const handleEditReview = (productId: string, reviewId: number, newText: string) => {
    setReviews(prev => {
        const updatedList = (prev[productId] || []).map(r => 
            r.id === reviewId ? { ...r, text: newText, time: "Edited just now" } : r
        );
        const newReviews = { ...prev, [productId]: updatedList };
        localStorage.setItem('mpt_reviews', JSON.stringify(newReviews));
        return newReviews;
    });
  };

  const handleSaveJournal = (entry: any) => {
      const newEntries = [entry, ...journalEntries];
      setJournalEntries(newEntries);
      if (user) persistUserData(user.name, savedItems, purchasedItems, user.tier, newEntries);
  };

  const addToBookmarks = (item: SavedItem) => {
    const isDuplicate = savedItems.some(i => i.type === item.type && (i.content === item.content || (i.title && i.title === item.title)));
    if (!isDuplicate) {
      const newSaved = [...savedItems, item];
      setSavedItems(newSaved);
      if (user) persistUserData(user.name, newSaved, purchasedItems, user.tier, journalEntries);
    }
  };

  const removeFromBookmarks = (id: string) => {
    const newSaved = savedItems.filter(item => item.id !== id);
    setSavedItems(newSaved);
    if (user) persistUserData(user.name, newSaved, purchasedItems, user.tier, journalEntries);
  };

  const handleBuy = (item: SavedItem) => {
    if (!user) { setCurrentView('login'); return; }
    const isDuplicate = purchasedItems.some(i => i.title === item.title);
    if (!isDuplicate) {
        const newBought = [...purchasedItems, item];
        setPurchasedItems(newBought);
        persistUserData(user.name, savedItems, newBought, user.tier, journalEntries);
        setNotifications(prev => [{ id: Date.now().toString(), text: `Added ${item.title} to library.`, read: false }, ...prev]);
        alert(`Thank you! You have purchased ${item.title}.`);
    } else {
        alert("You already own this item.");
    }
  };

  const handlePlayTrack = (track: Track) => { setCurrentTrack(track); setIsPlaying(true); };
  const handleNavigate = (view: any) => { setCurrentView(view); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const handleViewProduct = (productId: string) => { setSelectedProductId(productId); handleNavigate('product'); };
  const handleReadProduct = (productId: string) => { setSelectedProductId(productId); handleNavigate('read'); }

  const handleUpdateProgress = (productId: string, percentage: number) => {
      setReadingProgress(prev => ({ ...prev, [productId]: percentage }));
      if (percentage > 10 && user) handleUpdateProfile({ streak: user.streak + 1 });
  };

  const handleAddHighlight = (productId: string, highlight: {text: string, color: string, note?: string}) => {
      setHighlights(prev => {
          const current = prev[productId] || [];
          return { ...prev, [productId]: [...current, highlight] };
      });
  };

  const activeProduct = PRODUCTS.find(p => p.id === selectedProductId);
  // Added type cast to fix "Property 'filter' does not exist on type 'unknown'" error on line 323
  const userReviews = user ? Object.entries(reviews).flatMap(([vol, list]) => (list as any[]).filter(r => r.user === user.displayName).map(r => ({ ...r, productTitle: vol }))) : [];

  if (!onboardingComplete) return <Onboarding onComplete={completeOnboarding} />;

  return (
    <div className="min-h-screen pb-24">
      <Navbar onNavigate={handleNavigate} user={user} onLogout={handleLogout} notifications={notifications} />
      
      {currentView === 'home' && (
        <>
          <Hero onNavigate={handleNavigate} />
          <Marquee />
          <Bestseller onBuy={(data) => handleBuy({ id: Date.now().toString(), type: 'product', content: 'bg-[#F2F0EB]', title: data.title, vol: 'Vol. 01', productType: 'Guide', price: data.price })} />
          <Affirmation onSave={(text) => addToBookmarks({ id: Date.now().toString(), type: 'affirmation', content: text })} />
          <Moodboard onSave={(item) => addToBookmarks({ ...item, id: Date.now().toString(), type: 'mood' })} />
          <Testimonials />
          <EmailCapture />
          <FAQ />
          <Manifesto />
        </>
      )}

      {currentView === 'library' && (
          <Library products={PRODUCTS} onViewProduct={handleViewProduct} onSave={(data) => addToBookmarks({ id: Date.now().toString(), type: 'product', content: data.bgColor, title: data.title, vol: data.vol, productType: data.type, price: data.price, image: data.image })} />
      )}

      {currentView === 'product' && activeProduct && (
          <ProductDetail product={activeProduct} reviews={reviews[activeProduct.id] || []} onPostReview={(text, isAnon) => handleAddReview(activeProduct.id, text, isAnon)} user={user} onUpgrade={handleUpgrade} onBuy={handleBuy} onSave={addToBookmarks} onBack={() => handleNavigate('library')} onRead={() => handleReadProduct(activeProduct.id)} />
      )}

      {currentView === 'read' && activeProduct && (
          <Reader product={activeProduct} progress={readingProgress[activeProduct.id] || 0} highlights={highlights[activeProduct.id] || []} onUpdateProgress={(p) => handleUpdateProgress(activeProduct.id, p)} onAddHighlight={(h) => handleAddHighlight(activeProduct.id, h)} onBack={() => handleNavigate('profile')} user={user} />
      )}

      {currentView === 'profile' && user && (
          <Profile user={user} onUpdateProfile={handleUpdateProfile} readingProgress={readingProgress} products={PRODUCTS} purchasedItems={purchasedItems} savedItems={savedItems} userReviews={userReviews} onRemove={removeFromBookmarks} onNavigate={handleNavigate} onRead={handleReadProduct} />
      )}

      {currentView === 'club' && (
        <BookClub products={PRODUCTS} reviews={reviews} onPostReview={handleAddReview} onEditReview={handleEditReview} user={user} onNavigate={handleNavigate} onUpgrade={handleUpgrade} />
      )}

      {currentView === 'comfort' && (
          <ComfortLibrary onPlay={handlePlayTrack} currentTrackId={currentTrack?.id} purchasedTitles={purchasedItems.map(i => i.title || '')} onUnlock={(track) => handleBuy({ id: Date.now().toString(), type: 'product', title: track.title, price: '4.00', content: track.coverColor, productType: 'Audio Track', image: 'https://images.unsplash.com/photo-1516280440614-6697288d5d38?q=80&w=800&auto=format&fit=crop' })} />
      )}

      {currentView === 'journal' && (
          <PrivateJournal entries={journalEntries} onSaveEntry={handleSaveJournal} user={user} onNavigate={handleNavigate} />
      )}

      {currentView === 'login' && <Login onLogin={handleLogin} />}
      
      <Footer />
      {currentTrack && <AudioPlayer track={currentTrack} isPlaying={isPlaying} onTogglePlay={() => setIsPlaying(!isPlaying)} onClose={() => { setCurrentTrack(null); setIsPlaying(false); }} />}
    </div>
  );
}
